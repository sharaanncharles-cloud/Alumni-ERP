"""API regression tests for alumni platform auth, admin, profile, messaging, gamification, analytics."""

import os
import uuid
from urllib.parse import parse_qs, urlparse

import pytest
import requests


BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")


@pytest.fixture(scope="session")
def api_client():
    if not BASE_URL:
        pytest.fail("REACT_APP_BACKEND_URL environment variable is required")
    session = requests.Session()
    session.headers.update({"Content-Type": "application/json"})
    return session


@pytest.fixture(scope="session")
def admin_token(api_client):
    response = api_client.post(
        f"{BASE_URL}/api/auth/login",
        json={"username": "admin", "password": "butteryellow"},
        timeout=20,
    )
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data.get("access_token"), str)
    return data["access_token"]


@pytest.fixture()
def admin_client(api_client, admin_token):
    api_client.headers.update({"Authorization": f"Bearer {admin_token}"})
    return api_client


def _create_test_user(admin_client, prefix: str):
    unique = uuid.uuid4().hex[:8]
    username = f"{prefix}_{unique}".lower()
    payload = {
        "name": f"TEST {prefix} {unique}",
        "username": username,
        "roles": ["student"],
        "personal_email": f"{username}@example.com",
        "course": "Computer Science",
        "batch": "2026",
    }
    response = admin_client.post(f"{BASE_URL}/api/admin/users", json=payload, timeout=20)
    assert response.status_code == 200
    data = response.json()
    assert data["user"]["username"] == username
    assert isinstance(data["user"]["user_id"], str)
    return data


def test_api_root_live(api_client):
    response = api_client.get(f"{BASE_URL}/api/", timeout=20)
    assert response.status_code == 200
    assert response.json().get("message") == "AlumniConnect API is live"


def test_admin_login_default_credentials(api_client):
    response = api_client.post(
        f"{BASE_URL}/api/auth/login",
        json={"username": "admin", "password": "butteryellow"},
        timeout=20,
    )
    assert response.status_code == 200
    data = response.json()
    assert data["user"]["username"] == "admin"
    assert "must_change_password" in data


def test_auth_me_returns_admin(admin_client):
    response = admin_client.get(f"{BASE_URL}/api/auth/me", timeout=20)
    assert response.status_code == 200
    data = response.json()
    assert data["user"]["username"] == "admin"
    assert "admin" in data["user"]["roles"]


def test_admin_users_create_list_role_toggle_reset(admin_client):
    created = _create_test_user(admin_client, "adminworkflow")
    user_id = created["user"]["user_id"]

    list_response = admin_client.get(f"{BASE_URL}/api/admin/users", timeout=20)
    assert list_response.status_code == 200
    users = list_response.json().get("users", [])
    created_user = next((u for u in users if u["user_id"] == user_id), None)
    assert created_user is not None
    assert created_user["username"] == created["user"]["username"]

    toggle_response = admin_client.post(
        f"{BASE_URL}/api/admin/users/{user_id}/roles",
        json={"roles": ["student", "alumni"]},
        timeout=20,
    )
    assert toggle_response.status_code == 200
    assert toggle_response.json().get("message") == "Roles updated"

    verify_response = admin_client.get(f"{BASE_URL}/api/admin/users", timeout=20)
    toggled_user = next((u for u in verify_response.json().get("users", []) if u["user_id"] == user_id), None)
    assert sorted(toggled_user["roles"]) == ["alumni", "student"]

    reset_response = admin_client.post(
        f"{BASE_URL}/api/admin/users/{user_id}/reset-password",
        json={},
        timeout=20,
    )
    assert reset_response.status_code == 200
    reset_data = reset_response.json()
    assert reset_data.get("message") == "Temporary password reset successfully"
    assert isinstance(reset_data.get("temporary_password"), str)


def test_forgot_and_reset_password_flow(admin_client, api_client):
    created = _create_test_user(admin_client, "resetflow")
    username = created["user"]["username"]

    forgot_response = api_client.post(
        f"{BASE_URL}/api/auth/forgot-password",
        json={"identifier": username},
        timeout=20,
    )
    assert forgot_response.status_code == 200
    forgot_data = forgot_response.json()
    assert forgot_data.get("message") == "If account exists, password reset link has been sent."
    assert isinstance(forgot_data.get("reset_link_preview"), str)

    token = parse_qs(urlparse(forgot_data["reset_link_preview"]).query).get("token", [""])[0]
    assert token

    new_password = f"NewPass!{uuid.uuid4().hex[:6]}"
    reset_response = api_client.post(
        f"{BASE_URL}/api/auth/reset-password",
        json={"token": token, "new_password": new_password},
        timeout=20,
    )
    assert reset_response.status_code == 200
    assert reset_response.json().get("message") == "Password reset successful"

    login_response = api_client.post(
        f"{BASE_URL}/api/auth/login",
        json={"username": username, "password": new_password},
        timeout=20,
    )
    assert login_response.status_code == 200
    assert login_response.json()["user"]["username"] == username


def test_profile_update_persists(admin_client):
    new_bio = f"TEST updated bio {uuid.uuid4().hex[:6]}"
    update_response = admin_client.put(
        f"{BASE_URL}/api/profiles/me",
        json={"bio": new_bio},
        timeout=20,
    )
    assert update_response.status_code == 200
    assert update_response.json().get("message") == "Profile updated"

    me_response = admin_client.get(f"{BASE_URL}/api/profiles/me", timeout=20)
    assert me_response.status_code == 200
    assert me_response.json()["profile"]["bio"] == new_bio


def test_directory_profiles_alumni_load(admin_client):
    response = admin_client.get(
        f"{BASE_URL}/api/profiles",
        params={"role": "alumni"},
        timeout=20,
    )
    assert response.status_code == 200
    profiles = response.json().get("profiles", [])
    assert isinstance(profiles, list)
    assert len(profiles) > 0
    assert all("user_id" in profile for profile in profiles)


def test_messaging_direct_and_group_flow(admin_client):
    profiles_response = admin_client.get(f"{BASE_URL}/api/profiles", timeout=20)
    profiles = profiles_response.json().get("profiles", [])
    other_user = next((profile for profile in profiles if profile.get("username") != "admin"), None)
    assert other_user is not None

    message_text = f"TEST direct message {uuid.uuid4().hex[:6]}"
    direct_response = admin_client.post(
        f"{BASE_URL}/api/messages/direct",
        json={"to_user_id": other_user["user_id"], "content": message_text},
        timeout=20,
    )
    assert direct_response.status_code == 200
    assert direct_response.json().get("message") == "Direct message sent"

    conversation_response = admin_client.get(
        f"{BASE_URL}/api/messages/direct/{other_user['user_id']}",
        timeout=20,
    )
    assert conversation_response.status_code == 200
    messages = conversation_response.json().get("messages", [])
    assert any(msg.get("content") == message_text for msg in messages)

    group_name = f"TEST group {uuid.uuid4().hex[:6]}"
    create_group_response = admin_client.post(
        f"{BASE_URL}/api/messages/groups",
        json={"name": group_name, "member_ids": [other_user["user_id"]]},
        timeout=20,
    )
    assert create_group_response.status_code == 200
    group = create_group_response.json().get("group", {})
    assert group.get("name") == group_name

    group_text = f"TEST group msg {uuid.uuid4().hex[:6]}"
    send_group_response = admin_client.post(
        f"{BASE_URL}/api/messages/groups/{group['group_id']}/messages",
        json={"content": group_text},
        timeout=20,
    )
    assert send_group_response.status_code == 200
    assert send_group_response.json().get("message") == "Group message sent"

    groups_response = admin_client.get(f"{BASE_URL}/api/messages/groups", timeout=20)
    groups = groups_response.json().get("groups", [])
    created_group = next((item for item in groups if item.get("group_id") == group["group_id"]), None)
    assert created_group is not None
    assert any(msg.get("content") == group_text for msg in created_group.get("messages", []))


def test_admin_announcement_post_flow(admin_client):
    announcement_title = f"TEST Announcement {uuid.uuid4().hex[:6]}"
    announcement_message = "Testing announcement publish flow"

    post_response = admin_client.post(
        f"{BASE_URL}/api/announcements",
        json={"title": announcement_title, "message": announcement_message},
        timeout=20,
    )
    assert post_response.status_code == 200
    announcement = post_response.json().get("announcement", {})
    assert announcement.get("title") == announcement_title

    list_response = admin_client.get(f"{BASE_URL}/api/announcements", timeout=20)
    assert list_response.status_code == 200
    announcements = list_response.json().get("announcements", [])
    assert any(item.get("announcement_id") == announcement.get("announcement_id") for item in announcements)


def test_gamification_challenge_applaud_referral_leaderboard(admin_client):
    profiles_response = admin_client.get(f"{BASE_URL}/api/profiles", timeout=20)
    profiles = profiles_response.json().get("profiles", [])
    target_user = next((profile for profile in profiles if profile.get("username") != "admin"), None)
    student_user = next((profile for profile in profiles if "student" in profile.get("roles", [])), None)
    assert target_user is not None
    assert student_user is not None

    dashboard_before = admin_client.get(f"{BASE_URL}/api/gamification/dashboard", timeout=20)
    assert dashboard_before.status_code == 200
    challenges = dashboard_before.json().get("daily_challenges", [])
    assert len(challenges) > 0

    challenge_id = challenges[0]["id"]
    complete_response = admin_client.post(
        f"{BASE_URL}/api/gamification/challenges/{challenge_id}/complete",
        timeout=20,
    )
    assert complete_response.status_code == 200
    assert complete_response.json().get("message") in {
        "Challenge completed and points awarded",
        "Challenge already completed today",
    }

    applaud_response = admin_client.post(
        f"{BASE_URL}/api/gamification/applaud",
        json={"to_user_id": target_user["user_id"], "reason": "TEST appreciation"},
        timeout=20,
    )
    assert applaud_response.status_code == 200
    assert applaud_response.json().get("message") == "Applaud sent successfully"

    referral_response = admin_client.post(
        f"{BASE_URL}/api/gamification/referrals",
        json={
            "student_id": student_user["user_id"],
            "company": "TEST Corp",
            "job_title": "Analyst",
            "status": "successful",
        },
        timeout=20,
    )
    assert referral_response.status_code == 200
    referral = referral_response.json().get("referral", {})
    assert referral.get("status") == "successful"
    assert referral.get("company") == "TEST Corp"

    leaderboard_response = admin_client.get(f"{BASE_URL}/api/gamification/leaderboard", timeout=20)
    assert leaderboard_response.status_code == 200
    leaderboard = leaderboard_response.json().get("leaderboard", [])
    assert isinstance(leaderboard, list)
    assert len(leaderboard) > 0
    assert all("name" in entry and "gamification_points" in entry for entry in leaderboard)


def test_analytics_loads_bar_and_pie_data(admin_client):
    response = admin_client.get(f"{BASE_URL}/api/admin/analytics", timeout=20)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data.get("placements_by_course"), list)
    assert isinstance(data.get("placements_by_company"), list)
    assert "totals" in data and isinstance(data["totals"].get("users"), int)
