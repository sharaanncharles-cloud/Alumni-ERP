import asyncio
import logging
import os
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

import resend
from dotenv import load_dotenv
from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from motor.motor_asyncio import AsyncIOMotorClient
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr, Field
from starlette.middleware.cors import CORSMiddleware


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

# MongoDB connection
mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

SECRET_KEY = os.environ["SECRET_KEY"]
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.environ["ACCESS_TOKEN_EXPIRE_MINUTES"])
RESET_TOKEN_EXPIRE_MINUTES = int(os.environ["RESET_TOKEN_EXPIRE_MINUTES"])
ALGORITHM = "HS256"
RESEND_API_KEY = os.environ.get("RESEND_API_KEY", "")
SENDER_EMAIL = os.environ.get("SENDER_EMAIL", "")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


app = FastAPI(title="AlumniConnect API")
api_router = APIRouter(prefix="/api")


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


RoleType = Literal["admin", "student", "alumni", "teacher"]


class CareerEntry(BaseModel):
    company: str
    role: str
    start_date: Optional[str] = None
    end_date: Optional[str] = None


class LoginRequest(BaseModel):
    username: str
    password: str


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str


class ForgotPasswordRequest(BaseModel):
    identifier: str


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str


class AdminCreateUserRequest(BaseModel):
    name: str
    department: Optional[str] = None
    username: str
    profile_image_url: Optional[str] = None
    roles: List[RoleType]
    batch: Optional[str] = None
    course: Optional[str] = None
    currently_pursuing: bool = True
    degree_level: Optional[str] = None
    passed_out: Optional[str] = None
    placed_from_college: bool = False
    companies_worked_in: List[str] = Field(default_factory=list)
    internship_done: List[str] = Field(default_factory=list)
    interests: List[str] = Field(default_factory=list)
    bio: Optional[str] = None
    personal_email: Optional[EmailStr] = None
    college_email: Optional[EmailStr] = None
    committees: List[str] = Field(default_factory=list)
    groups: List[str] = Field(default_factory=list)
    career_history: List[CareerEntry] = Field(default_factory=list)
    mentorship_available: bool = False
    mentorship_categories: List[str] = Field(default_factory=list)
    current_role: Optional[str] = None
    current_company: Optional[str] = None
    temporary_password: Optional[str] = None


class AdminUpdateUserRequest(BaseModel):
    name: Optional[str] = None
    profile_image_url: Optional[str] = None
    department: Optional[str] = None
    roles: Optional[List[RoleType]] = None
    batch: Optional[str] = None
    course: Optional[str] = None
    currently_pursuing: Optional[bool] = None
    degree_level: Optional[str] = None
    passed_out: Optional[str] = None
    placed_from_college: Optional[bool] = None
    companies_worked_in: Optional[List[str]] = None
    internship_done: Optional[List[str]] = None
    interests: Optional[List[str]] = None
    bio: Optional[str] = None
    personal_email: Optional[EmailStr] = None
    college_email: Optional[EmailStr] = None
    committees: Optional[List[str]] = None
    groups: Optional[List[str]] = None
    career_history: Optional[List[CareerEntry]] = None
    mentorship_available: Optional[bool] = None
    mentorship_categories: Optional[List[str]] = None
    current_role: Optional[str] = None
    current_company: Optional[str] = None


class RoleAssignRequest(BaseModel):
    roles: List[RoleType]


class AdminResetPasswordRequest(BaseModel):
    new_temporary_password: Optional[str] = None


class ProfileUpdateRequest(BaseModel):
    name: Optional[str] = None
    profile_image_url: Optional[str] = None
    department: Optional[str] = None
    batch: Optional[str] = None
    course: Optional[str] = None
    currently_pursuing: Optional[bool] = None
    degree_level: Optional[str] = None
    passed_out: Optional[str] = None
    placed_from_college: Optional[bool] = None
    companies_worked_in: Optional[List[str]] = None
    internship_done: Optional[List[str]] = None
    interests: Optional[List[str]] = None
    bio: Optional[str] = None
    personal_email: Optional[EmailStr] = None
    college_email: Optional[EmailStr] = None
    committees: Optional[List[str]] = None
    groups: Optional[List[str]] = None
    career_history: Optional[List[CareerEntry]] = None
    mentorship_available: Optional[bool] = None
    mentorship_categories: Optional[List[str]] = None
    current_role: Optional[str] = None
    current_company: Optional[str] = None


class DirectMessageCreateRequest(BaseModel):
    to_user_id: str
    content: str


class GroupChatCreateRequest(BaseModel):
    name: str
    member_ids: List[str] = Field(default_factory=list)


class GroupMessageCreateRequest(BaseModel):
    content: str


class AnnouncementCreateRequest(BaseModel):
    title: str
    message: str


class ApplaudRequest(BaseModel):
    to_user_id: str
    reason: Optional[str] = None


class ReferralCreateRequest(BaseModel):
    student_id: str
    company: str
    job_title: str
    status: Literal["pending", "successful", "rejected"] = "pending"


class MiniGameScoreRequest(BaseModel):
    game_type: Literal["tap_speed", "memory_flip"]
    score: int


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def resolve_public_base_url(request: Request) -> str:
    origin = request.headers.get("origin")
    if origin:
        return origin.rstrip("/")

    forwarded_host = request.headers.get("x-forwarded-host")
    forwarded_proto = request.headers.get("x-forwarded-proto") or "https"
    if forwarded_host:
        return f"{forwarded_proto}://{forwarded_host}".rstrip("/")

    host = request.headers.get("host")
    if host:
        return f"{forwarded_proto}://{host}".rstrip("/")

    return str(request.base_url).rstrip("/")


def parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(value)


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, password_hash: str) -> bool:
    return pwd_context.verify(plain_password, password_hash)


def create_access_token(data: Dict[str, Any], expires_minutes: int) -> str:
    payload = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=expires_minutes)
    payload.update({"exp": expire})
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def clean_list(values: Optional[List[str]]) -> List[str]:
    if not values:
        return []
    return sorted({item.strip() for item in values if item and item.strip()})


def calculate_badges(user_doc: Dict[str, Any]) -> List[str]:
    badges: List[str] = []
    if user_doc.get("mentorship_sessions", 0) >= 5:
        badges.append("Top Mentor")
    if user_doc.get("successful_referrals", 0) >= 3:
        badges.append("Top Referrer")
    if user_doc.get("placed_from_college"):
        badges.append("Career Success Story")
    if user_doc.get("streak_count", 0) >= 5:
        badges.append("Consistency Champion")
    return badges


def sanitize_user(doc: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not doc:
        return None
    safe_doc = {k: v for k, v in doc.items() if k not in {"_id", "password_hash"}}
    safe_doc.setdefault("roles", [])
    safe_doc.setdefault("interests", [])
    safe_doc.setdefault("committees", [])
    safe_doc.setdefault("groups", [])
    safe_doc.setdefault("career_history", [])
    safe_doc.setdefault("companies_worked_in", [])
    safe_doc.setdefault("internship_done", [])
    safe_doc.setdefault("mentorship_categories", [])
    safe_doc.setdefault("badges", [])
    safe_doc.setdefault("profile_image_url", None)
    return safe_doc


async def send_email_with_resend(recipient: str, subject: str, html_body: str) -> Dict[str, Any]:
    if not RESEND_API_KEY or not SENDER_EMAIL:
        logger.warning("Resend not configured. Skipping email to %s", recipient)
        return {"sent": False, "reason": "resend_not_configured"}

    resend.api_key = RESEND_API_KEY
    params = {
        "from": SENDER_EMAIL,
        "to": [recipient],
        "subject": subject,
        "html": html_body,
    }

    try:
        response = await asyncio.to_thread(resend.Emails.send, params)
        return {"sent": True, "id": response.get("id")}
    except Exception as exc:  # noqa: BLE001
        logger.error("Resend email failed: %s", exc)
        return {"sent": False, "reason": str(exc)}


def generate_temp_password() -> str:
    return f"Alumni@{str(uuid.uuid4()).split('-')[0]}"


async def get_user_by_user_id(user_id: str) -> Optional[Dict[str, Any]]:
    return await db.users.find_one({"user_id": user_id}, {"_id": 0})


async def get_current_user(token: str = Depends(oauth2_scheme)) -> Dict[str, Any]:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid authentication token",
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: Optional[str] = payload.get("sub")
        if not user_id:
            raise credentials_exception
    except JWTError as exc:
        raise credentials_exception from exc

    user = await get_user_by_user_id(user_id)
    if not user:
        raise credentials_exception
    if not user.get("is_active", True):
        raise HTTPException(status_code=403, detail="This account is inactive")
    return user


def require_roles(required_roles: List[RoleType]):
    async def role_checker(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
        current_roles = current_user.get("roles", [])
        if not any(role in current_roles for role in required_roles):
            raise HTTPException(status_code=403, detail="Access denied")
        return current_user

    return role_checker


async def ensure_default_admin() -> None:
    admin = await db.users.find_one({"username": "admin"})
    if admin:
        return

    admin_doc = {
        "user_id": str(uuid.uuid4()),
        "username": "admin",
        "name": "Admin",
        "department": "Administration",
        "profile_image_url": None,
        "roles": ["admin"],
        "password_hash": hash_password("butteryellow"),
        "must_change_password": True,
        "batch": None,
        "course": None,
        "currently_pursuing": False,
        "degree_level": None,
        "passed_out": None,
        "placed_from_college": False,
        "companies_worked_in": [],
        "internship_done": [],
        "interests": ["Operations", "Mentorship", "Placements"],
        "bio": "Default admin account. Please change password after first login.",
        "personal_email": None,
        "college_email": None,
        "committees": [],
        "groups": [],
        "career_history": [],
        "mentorship_available": False,
        "mentorship_categories": [],
        "current_role": "Administrator",
        "current_company": "College Administration",
        "gamification_points": 0,
        "streak_count": 0,
        "applauds_received": 0,
        "referral_points": 0,
        "successful_referrals": 0,
        "mentorship_sessions": 0,
        "badges": [],
        "is_active": True,
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "is_seed": True,
    }
    await db.users.insert_one(admin_doc)
    logger.info("Default admin created: username=admin password=butteryellow")


async def seed_profiles() -> None:
    existing_seed_count = await db.users.count_documents({"seed_profile": True})
    if existing_seed_count > 0:
        return

    seed_docs = [
        {
            "user_id": str(uuid.uuid4()),
            "username": "atul.alumni",
            "name": "Atul",
            "profile_image_url": "https://static.prod-images.emergentagent.com/jobs/41ca8096-f5a0-4243-979a-c0c2bb6c1bc3/images/ab86d4e2e338a5deed8314b20c2e2e4a08807a227cfb46e8d65d872b1b19d24f.png",
            "roles": ["alumni"],
            "password_hash": hash_password("atul1234"),
            "must_change_password": True,
            "batch": "2018",
            "course": "Business Administration",
            "currently_pursuing": False,
            "degree_level": "UG",
            "passed_out": "2018",
            "placed_from_college": True,
            "companies_worked_in": ["HomeSphere Realty", "UrbanNest"],
            "internship_done": ["College Incubation Cell"],
            "interests": ["Real Estate", "Startup", "Design"],
            "department": "Business & Entrepreneurship",
            "bio": "Hola, I’m Atul. I finished my college where I learned plenty of theoretical knowledge about the world, but in the real world, I’ve mixed my passion and excitement into building my own startup. I’m a real estate agent, but not just helping people find houses — I help people find homes that are extensions of who they are.",
            "personal_email": "atul@example.com",
            "college_email": "atul@college.edu",
            "committees": ["Entrepreneurship Cell"],
            "groups": ["Founders Circle"],
            "career_history": [
                {"company": "HomeSphere Realty", "role": "Associate", "start_date": "2019", "end_date": "2021"},
                {"company": "UrbanNest", "role": "Founder", "start_date": "2021", "end_date": "Present"},
            ],
            "mentorship_available": True,
            "mentorship_categories": ["Startups", "Sales", "Real Estate"],
            "current_role": "Founder",
            "current_company": "UrbanNest",
            "gamification_points": 120,
            "streak_count": 3,
            "applauds_received": 8,
            "referral_points": 40,
            "successful_referrals": 2,
            "mentorship_sessions": 6,
            "badges": ["Top Mentor"],
            "is_active": True,
            "created_at": now_iso(),
            "updated_at": now_iso(),
            "seed_profile": True,
        },
        {
            "user_id": str(uuid.uuid4()),
            "username": "marie.student",
            "name": "Marie",
            "profile_image_url": "https://static.prod-images.emergentagent.com/jobs/41ca8096-f5a0-4243-979a-c0c2bb6c1bc3/images/5b5de56773313bd1553088184a095954c920b793663c95b229ffca0ebf203dee.png",
            "roles": ["student"],
            "password_hash": hash_password("marie1234"),
            "must_change_password": True,
            "batch": "2026",
            "course": "Applied Mathematics",
            "currently_pursuing": True,
            "degree_level": "UG",
            "passed_out": None,
            "placed_from_college": False,
            "companies_worked_in": ["Metaforms"],
            "internship_done": ["Data Analyst Intern - Metaforms"],
            "interests": ["Data Analytics", "Music", "Storytelling"],
            "department": "Applied Mathematics",
            "bio": "Hey, I’m Marie. I’m currently pursuing Applied Mathematics and interning at Company Metaforms as a Data Analyst. Huge shoutout to Stegnis for referring me to this marvelous role.",
            "personal_email": "marie@example.com",
            "college_email": "marie@college.edu",
            "committees": ["Tech Society", "Music Club"],
            "groups": ["Data Circle"],
            "career_history": [
                {"company": "Metaforms", "role": "Data Analyst Intern", "start_date": "2025", "end_date": "Present"}
            ],
            "mentorship_available": False,
            "mentorship_categories": [],
            "current_role": "Student",
            "current_company": "Metaforms",
            "gamification_points": 65,
            "streak_count": 2,
            "applauds_received": 5,
            "referral_points": 10,
            "successful_referrals": 0,
            "mentorship_sessions": 1,
            "badges": [],
            "is_active": True,
            "created_at": now_iso(),
            "updated_at": now_iso(),
            "seed_profile": True,
        },
        {
            "user_id": str(uuid.uuid4()),
            "username": "annie.student",
            "name": "Annie",
            "profile_image_url": "https://static.prod-images.emergentagent.com/jobs/41ca8096-f5a0-4243-979a-c0c2bb6c1bc3/images/f7a4172f187125aaac677a9db383918377cc938b0663e2a8e1979f857a80e16e.png",
            "roles": ["student"],
            "password_hash": hash_password("annie1234"),
            "must_change_password": True,
            "batch": "2027",
            "course": "Architecture",
            "currently_pursuing": True,
            "degree_level": "UG",
            "passed_out": None,
            "placed_from_college": False,
            "companies_worked_in": ["Zuz"],
            "internship_done": ["Architecture Intern - Zuz"],
            "interests": ["Architecture", "Sports", "Collaboration"],
            "department": "Architecture",
            "bio": "Hey, I’m Annie. I’m currently pursuing Architecture and interning at Company Zuz. Huge shout-out to Yogata for referring me to this incredible opportunity.",
            "personal_email": "annie@example.com",
            "college_email": "annie@college.edu",
            "committees": ["Design Club", "Sports Committee"],
            "groups": ["Architecture Guild"],
            "career_history": [
                {"company": "Zuz", "role": "Architecture Intern", "start_date": "2025", "end_date": "Present"}
            ],
            "mentorship_available": False,
            "mentorship_categories": [],
            "current_role": "Student",
            "current_company": "Zuz",
            "gamification_points": 58,
            "streak_count": 1,
            "applauds_received": 3,
            "referral_points": 10,
            "successful_referrals": 0,
            "mentorship_sessions": 2,
            "badges": [],
            "is_active": True,
            "created_at": now_iso(),
            "updated_at": now_iso(),
            "seed_profile": True,
        },
    ]
    await db.users.insert_many(seed_docs)


async def init_indexes() -> None:
    await db.users.create_index("username", unique=True)
    await db.users.create_index("user_id", unique=True)
    await db.password_reset_tokens.create_index("token", unique=True)
    await db.direct_messages.create_index([("to_user_id", 1), ("from_user_id", 1), ("created_at", -1)])
    await db.mini_game_scores.create_index([("user_id", 1), ("game_type", 1)], unique=True)


@app.on_event("startup")
async def startup_event() -> None:
    await init_indexes()
    await ensure_default_admin()
    await seed_profiles()


@api_router.get("/")
async def root() -> Dict[str, str]:
    return {"message": "AlumniConnect API is live"}


@api_router.post("/auth/login")
async def login(payload: LoginRequest) -> Dict[str, Any]:
    username = payload.username.strip().lower()
    user_doc = await db.users.find_one({"username": username}, {"_id": 0})
    if not user_doc or not verify_password(payload.password, user_doc["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    if not user_doc.get("is_active", True):
        raise HTTPException(status_code=403, detail="Your account has been deactivated")

    access_token = create_access_token({"sub": user_doc["user_id"]}, ACCESS_TOKEN_EXPIRE_MINUTES)
    await db.users.update_one(
        {"user_id": user_doc["user_id"]},
        {"$set": {"last_login_at": now_iso(), "updated_at": now_iso()}},
    )

    safe_user = sanitize_user(user_doc)
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "must_change_password": safe_user.get("must_change_password", False),
        "user": safe_user,
    }


@api_router.get("/auth/me")
async def get_me(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    return {"user": sanitize_user(current_user)}


@api_router.post("/auth/change-password")
async def change_password(
    payload: ChangePasswordRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, str]:
    if len(payload.new_password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters long")

    if not verify_password(payload.current_password, current_user["password_hash"]):
        raise HTTPException(status_code=400, detail="Current password is incorrect")

    await db.users.update_one(
        {"user_id": current_user["user_id"]},
        {
            "$set": {
                "password_hash": hash_password(payload.new_password),
                "must_change_password": False,
                "password_changed_at": now_iso(),
                "updated_at": now_iso(),
            }
        },
    )
    return {"message": "Password changed successfully"}


@api_router.post("/auth/forgot-password")
async def forgot_password(payload: ForgotPasswordRequest, request: Request) -> Dict[str, Any]:
    identifier = payload.identifier.strip().lower()
    user_doc = await db.users.find_one(
        {
            "$or": [
                {"username": identifier},
                {"college_email": identifier},
                {"personal_email": identifier},
            ]
        },
        {"_id": 0},
    )

    if not user_doc:
        return {"message": "If account exists, password reset link has been sent."}

    reset_token = str(uuid.uuid4())
    expires_at = (datetime.now(timezone.utc) + timedelta(minutes=RESET_TOKEN_EXPIRE_MINUTES)).isoformat()
    await db.password_reset_tokens.insert_one(
        {
            "token": reset_token,
            "user_id": user_doc["user_id"],
            "used": False,
            "expires_at": expires_at,
            "created_at": now_iso(),
        }
    )

    recipient_email = user_doc.get("college_email") or user_doc.get("personal_email")
    reset_link = f"{resolve_public_base_url(request)}/reset-password?token={reset_token}"
    preview_link = f"/reset-password?token={reset_token}"

    email_result = {"sent": False, "reason": "no_recipient_email"}
    if recipient_email:
        email_html = f"""
        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"font-family: Arial, sans-serif;\">
          <tr><td style=\"padding:24px;\">
            <h2>AlumniConnect Password Reset</h2>
            <p>Hi {user_doc.get('name', 'there')},</p>
            <p>Click below to reset your password:</p>
            <p><a href=\"{reset_link}\" style=\"background:#1e3a8a;color:#fff;padding:10px 16px;text-decoration:none;border-radius:8px;\">Reset Password</a></p>
            <p>This link expires in {RESET_TOKEN_EXPIRE_MINUTES} minutes.</p>
          </td></tr>
        </table>
        """
        email_result = await send_email_with_resend(recipient_email, "Reset your AlumniConnect password", email_html)

    return {
        "message": "If account exists, password reset link has been sent.",
        "email_sent": email_result.get("sent", False),
        "reset_link_preview": None if email_result.get("sent", False) else preview_link,
    }


@api_router.post("/auth/reset-password")
async def reset_password(payload: ResetPasswordRequest) -> Dict[str, str]:
    token_doc = await db.password_reset_tokens.find_one({"token": payload.token, "used": False}, {"_id": 0})
    if not token_doc:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")

    if parse_iso(token_doc["expires_at"]) < datetime.now(timezone.utc):
        raise HTTPException(status_code=400, detail="Reset token has expired")

    if len(payload.new_password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters long")

    await db.users.update_one(
        {"user_id": token_doc["user_id"]},
        {
            "$set": {
                "password_hash": hash_password(payload.new_password),
                "must_change_password": False,
                "password_changed_at": now_iso(),
                "updated_at": now_iso(),
            }
        },
    )
    await db.password_reset_tokens.update_one(
        {"token": payload.token},
        {"$set": {"used": True, "used_at": now_iso()}},
    )
    return {"message": "Password reset successful"}


@api_router.get("/admin/users")
async def admin_list_users(
    current_user: Dict[str, Any] = Depends(require_roles(["admin"])),
) -> Dict[str, Any]:
    _ = current_user
    users = await db.users.find({}, {"_id": 0, "password_hash": 0}).sort("created_at", -1).to_list(2000)
    return {"users": users}


@api_router.post("/admin/users")
async def admin_create_user(
    payload: AdminCreateUserRequest,
    request: Request,
    current_user: Dict[str, Any] = Depends(require_roles(["admin"])),
) -> Dict[str, Any]:
    username = payload.username.strip().lower()
    existing = await db.users.find_one({"username": username}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Username already exists")

    if not payload.roles:
        raise HTTPException(status_code=400, detail="At least one role is required")

    temp_password = payload.temporary_password or generate_temp_password()
    user_doc = payload.model_dump()
    user_doc["username"] = username
    user_doc["roles"] = clean_list(user_doc.get("roles", []))
    user_doc["interests"] = clean_list(user_doc.get("interests", []))
    user_doc["committees"] = clean_list(user_doc.get("committees", []))
    user_doc["groups"] = clean_list(user_doc.get("groups", []))
    user_doc["companies_worked_in"] = clean_list(user_doc.get("companies_worked_in", []))
    user_doc["internship_done"] = clean_list(user_doc.get("internship_done", []))
    user_doc["mentorship_categories"] = clean_list(user_doc.get("mentorship_categories", []))
    user_doc["career_history"] = [entry.model_dump() for entry in payload.career_history]

    # Admin and mentor-style profiles keep minimal identity details
    if "admin" in user_doc["roles"] or payload.mentorship_available:
        user_doc["batch"] = None
        user_doc["course"] = None
        user_doc["currently_pursuing"] = False
        user_doc["degree_level"] = None
        user_doc["passed_out"] = None
        user_doc["placed_from_college"] = False
        user_doc["companies_worked_in"] = []
        user_doc["internship_done"] = []
        user_doc["committees"] = []
        user_doc["groups"] = []

    user_doc["password_hash"] = hash_password(temp_password)
    user_doc["must_change_password"] = True
    user_doc["user_id"] = str(uuid.uuid4())
    user_doc["created_by"] = current_user["user_id"]
    user_doc["created_at"] = now_iso()
    user_doc["updated_at"] = now_iso()
    user_doc["gamification_points"] = 0
    user_doc["streak_count"] = 0
    user_doc["applauds_received"] = 0
    user_doc["referral_points"] = 0
    user_doc["successful_referrals"] = 0
    user_doc["mentorship_sessions"] = 0
    user_doc["badges"] = []
    user_doc["is_active"] = True

    await db.users.insert_one(user_doc.copy())

    recipient_email = user_doc.get("college_email") or user_doc.get("personal_email")
    reset_link = f"{request.base_url}reset-password"
    email_result = {"sent": False, "reason": "no_recipient_email"}
    if recipient_email:
        email_html = f"""
        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"font-family: Arial, sans-serif;\">
          <tr><td style=\"padding:24px;\">
            <h2>Welcome to AlumniConnect</h2>
            <p>Hi {user_doc.get('name')}, your account has been created.</p>
            <p><b>Username:</b> {username}</p>
            <p><b>Temporary Password:</b> {temp_password}</p>
            <p>Please login and change your password immediately.</p>
            <p>Login URL: <a href=\"{request.base_url}login\">{request.base_url}login</a></p>
            <p>Forgot password URL: <a href=\"{reset_link}\">{reset_link}</a></p>
          </td></tr>
        </table>
        """
        email_result = await send_email_with_resend(recipient_email, "Your AlumniConnect account details", email_html)

    return {
        "message": "User created successfully",
        "user": sanitize_user(user_doc),
        "email_sent": email_result.get("sent", False),
        "temporary_password": None if email_result.get("sent", False) else temp_password,
    }


@api_router.put("/admin/users/{user_id}")
async def admin_update_user(
    user_id: str,
    payload: AdminUpdateUserRequest,
    current_user: Dict[str, Any] = Depends(require_roles(["admin"])),
) -> Dict[str, Any]:
    _ = current_user
    update_data = payload.model_dump(exclude_unset=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No update fields provided")

    if "roles" in update_data and not update_data["roles"]:
        raise HTTPException(status_code=400, detail="At least one role must remain assigned")

    for key in [
        "interests",
        "committees",
        "groups",
        "companies_worked_in",
        "internship_done",
        "mentorship_categories",
    ]:
        if key in update_data and update_data[key] is not None:
            update_data[key] = clean_list(update_data[key])

    if "career_history" in update_data and update_data["career_history"] is not None:
        update_data["career_history"] = [entry.model_dump() for entry in update_data["career_history"]]

    target_roles = update_data.get("roles")
    if target_roles is None:
        existing_user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "roles": 1, "mentorship_available": 1})
        target_roles = existing_user.get("roles", []) if existing_user else []
        target_mentor = existing_user.get("mentorship_available", False) if existing_user else False
    else:
        target_mentor = update_data.get("mentorship_available", False)

    if "mentorship_available" in update_data:
        target_mentor = update_data["mentorship_available"]

    if "admin" in target_roles or target_mentor:
        update_data.update(
            {
                "batch": None,
                "course": None,
                "currently_pursuing": False,
                "degree_level": None,
                "passed_out": None,
                "placed_from_college": False,
                "companies_worked_in": [],
                "internship_done": [],
                "committees": [],
                "groups": [],
            }
        )

    update_data["updated_at"] = now_iso()

    result = await db.users.update_one({"user_id": user_id}, {"$set": update_data})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")

    updated_user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "password_hash": 0})
    return {"message": "User updated successfully", "user": updated_user}


@api_router.post("/admin/users/{user_id}/roles")
async def admin_assign_roles(
    user_id: str,
    payload: RoleAssignRequest,
    current_user: Dict[str, Any] = Depends(require_roles(["admin"])),
) -> Dict[str, Any]:
    _ = current_user
    if not payload.roles:
        raise HTTPException(status_code=400, detail="At least one role must be assigned")

    result = await db.users.update_one(
        {"user_id": user_id},
        {"$set": {"roles": clean_list(payload.roles), "updated_at": now_iso()}},
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "Roles updated"}


@api_router.post("/admin/users/{user_id}/reset-password")
async def admin_reset_user_password(
    user_id: str,
    payload: AdminResetPasswordRequest,
    request: Request,
    current_user: Dict[str, Any] = Depends(require_roles(["admin"])),
) -> Dict[str, Any]:
    _ = current_user
    user_doc = await db.users.find_one({"user_id": user_id}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=404, detail="User not found")

    temp_password = payload.new_temporary_password or generate_temp_password()
    await db.users.update_one(
        {"user_id": user_id},
        {
            "$set": {
                "password_hash": hash_password(temp_password),
                "must_change_password": True,
                "updated_at": now_iso(),
            }
        },
    )

    recipient_email = user_doc.get("college_email") or user_doc.get("personal_email")
    email_result = {"sent": False, "reason": "no_recipient_email"}
    if recipient_email:
        email_html = f"""
        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"font-family: Arial, sans-serif;\">
          <tr><td style=\"padding:24px;\">
            <h2>Password Reset by Admin</h2>
            <p>Your temporary password is: <b>{temp_password}</b></p>
            <p>Login URL: <a href=\"{request.base_url}login\">{request.base_url}login</a></p>
          </td></tr>
        </table>
        """
        email_result = await send_email_with_resend(recipient_email, "Your AlumniConnect temporary password", email_html)

    return {
        "message": "Temporary password reset successfully",
        "email_sent": email_result.get("sent", False),
        "temporary_password": None if email_result.get("sent", False) else temp_password,
    }


@api_router.delete("/admin/users/{user_id}")
async def admin_soft_delete_user(
    user_id: str,
    current_user: Dict[str, Any] = Depends(require_roles(["admin"])),
) -> Dict[str, str]:
    _ = current_user
    target_user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "username": 1, "roles": 1})
    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")
    if target_user.get("username") == "admin":
        raise HTTPException(status_code=400, detail="Default admin cannot be deactivated")

    await db.users.update_one(
        {"user_id": user_id},
        {"$set": {"is_active": False, "deactivated_at": now_iso(), "updated_at": now_iso()}},
    )
    return {"message": "User deactivated successfully"}


@api_router.post("/admin/users/{user_id}/restore")
async def admin_restore_user(
    user_id: str,
    current_user: Dict[str, Any] = Depends(require_roles(["admin"])),
) -> Dict[str, str]:
    _ = current_user
    target_user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "username": 1})
    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")

    await db.users.update_one(
        {"user_id": user_id},
        {"$set": {"is_active": True, "updated_at": now_iso()}, "$unset": {"deactivated_at": ""}},
    )
    return {"message": "User restored successfully"}


@api_router.get("/admin/analytics")
async def admin_analytics(
    current_user: Dict[str, Any] = Depends(require_roles(["admin"])),
) -> Dict[str, Any]:
    _ = current_user
    users = await db.users.find(
        {"is_active": {"$ne": False}},
        {
            "_id": 0,
            "name": 1,
            "roles": 1,
            "course": 1,
            "placed_from_college": 1,
            "current_company": 1,
            "companies_worked_in": 1,
            "gamification_points": 1,
            "successful_referrals": 1,
        },
    ).to_list(5000)

    role_totals: Dict[str, int] = {"admin": 0, "student": 0, "alumni": 0, "teacher": 0}
    placements_by_course: Dict[str, int] = {}
    placements_by_company: Dict[str, int] = {}

    for user in users:
        for role in user.get("roles", []):
            if role in role_totals:
                role_totals[role] += 1

        if user.get("placed_from_college"):
            course = user.get("course") or "Unknown"
            placements_by_course[course] = placements_by_course.get(course, 0) + 1

            company = user.get("current_company")
            if not company:
                company_list = user.get("companies_worked_in") or []
                company = company_list[-1] if company_list else "Unknown"
            placements_by_company[company] = placements_by_company.get(company, 0) + 1

    leaderboard = sorted(users, key=lambda item: item.get("gamification_points", 0), reverse=True)[:10]
    leaderboard = [
        {
            "name": entry.get("name", "Unknown"),
            "points": entry.get("gamification_points", 0),
            "successful_referrals": entry.get("successful_referrals", 0),
        }
        for entry in leaderboard
    ]

    is_mock_data = False
    course_data = [{"course": key, "placements": value} for key, value in sorted(placements_by_course.items())]
    company_data = [{"company": key, "placements": value} for key, value in sorted(placements_by_company.items())]

    if not course_data and not company_data:
        is_mock_data = True
        course_data = [
            {"course": "Computer Science", "placements": 24},
            {"course": "Applied Mathematics", "placements": 16},
            {"course": "Architecture", "placements": 12},
            {"course": "Business", "placements": 18},
        ]
        company_data = [
            {"company": "Metaforms", "placements": 10},
            {"company": "UrbanNest", "placements": 8},
            {"company": "Zuz", "placements": 6},
            {"company": "HomeSphere Realty", "placements": 5},
            {"company": "TechNova", "placements": 7},
        ]

    return {
        "totals": {
            "users": len(users),
            "students": role_totals["student"],
            "alumni": role_totals["alumni"],
            "admins": role_totals["admin"],
            "teachers": role_totals["teacher"],
            "messages": await db.direct_messages.count_documents({}),
            "group_chats": await db.group_chats.count_documents({}),
            "announcements": await db.announcements.count_documents({}),
            "referrals": await db.referrals.count_documents({}),
        },
        "placements_by_course": course_data,
        "placements_by_company": company_data,
        "leaderboard": leaderboard,
        "is_mock_data": is_mock_data,
    }


@api_router.get("/admin/reports")
async def admin_reports(
    current_user: Dict[str, Any] = Depends(require_roles(["admin"])),
) -> Dict[str, Any]:
    _ = current_user
    total_challenge_completions = await db.challenge_completions.count_documents({})
    total_applauds = await db.applauds.count_documents({})
    total_mentorship_available = await db.users.count_documents({"mentorship_available": True})
    total_successful_referrals = await db.referrals.count_documents({"status": "successful"})
    return {
        "engagement": {
            "daily_challenge_completions": total_challenge_completions,
            "total_applauds": total_applauds,
        },
        "mentorship": {
            "mentors_available": total_mentorship_available,
        },
        "corporate_interactions": {
            "successful_referrals": total_successful_referrals,
        },
    }


@api_router.get("/profiles")
async def list_profiles(
    role: Optional[str] = None,
    batch: Optional[str] = None,
    course: Optional[str] = None,
    search: Optional[str] = None,
    _: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    query: Dict[str, Any] = {"is_active": {"$ne": False}}
    if role:
        query["roles"] = role
    if batch:
        query["batch"] = batch
    if course:
        query["course"] = course
    if search:
        regex = {"$regex": search, "$options": "i"}
        query["$or"] = [
            {"name": regex},
            {"course": regex},
            {"department": regex},
            {"bio": regex},
            {"current_company": regex},
        ]

    profiles = await db.users.find(query, {"_id": 0, "password_hash": 0}).to_list(1000)
    return {"profiles": profiles}


@api_router.get("/profiles/me")
async def get_my_profile(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    return {"profile": sanitize_user(current_user)}


@api_router.put("/profiles/me")
async def update_my_profile(
    payload: ProfileUpdateRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    update_data = payload.model_dump(exclude_unset=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No updates provided")

    for key in [
        "interests",
        "committees",
        "groups",
        "companies_worked_in",
        "internship_done",
        "mentorship_categories",
    ]:
        if key in update_data and update_data[key] is not None:
            update_data[key] = clean_list(update_data[key])

    if "career_history" in update_data and update_data["career_history"] is not None:
        update_data["career_history"] = [entry.model_dump() for entry in update_data["career_history"]]

    current_roles = current_user.get("roles", [])
    target_mentor = update_data.get("mentorship_available", current_user.get("mentorship_available", False))
    if "admin" in current_roles or target_mentor:
        update_data.update(
            {
                "batch": None,
                "course": None,
                "currently_pursuing": False,
                "degree_level": None,
                "passed_out": None,
                "placed_from_college": False,
                "companies_worked_in": [],
                "internship_done": [],
                "committees": [],
                "groups": [],
            }
        )

    update_data["updated_at"] = now_iso()
    await db.users.update_one({"user_id": current_user["user_id"]}, {"$set": update_data})
    refreshed = await db.users.find_one({"user_id": current_user["user_id"]}, {"_id": 0})
    return {"message": "Profile updated", "profile": sanitize_user(refreshed)}


@api_router.get("/profiles/{user_id}")
async def get_profile(user_id: str, _: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    profile = await db.users.find_one({"user_id": user_id}, {"_id": 0, "password_hash": 0})
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return {"profile": profile}


@api_router.post("/messages/direct")
async def send_direct_message(
    payload: DirectMessageCreateRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    if not payload.content.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    recipient = await db.users.find_one({"user_id": payload.to_user_id}, {"_id": 0, "user_id": 1})
    if not recipient:
        raise HTTPException(status_code=404, detail="Recipient not found")

    message_doc = {
        "message_id": str(uuid.uuid4()),
        "from_user_id": current_user["user_id"],
        "to_user_id": payload.to_user_id,
        "content": payload.content.strip(),
        "created_at": now_iso(),
    }
    await db.direct_messages.insert_one(message_doc.copy())
    return {"message": "Direct message sent", "data": message_doc}


@api_router.get("/messages/direct/{other_user_id}")
async def get_direct_messages(
    other_user_id: str,
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    conversation = await db.direct_messages.find(
        {
            "$or": [
                {"from_user_id": current_user["user_id"], "to_user_id": other_user_id},
                {"from_user_id": other_user_id, "to_user_id": current_user["user_id"]},
            ]
        },
        {"_id": 0},
    ).sort("created_at", 1).to_list(2000)
    return {"messages": conversation}


@api_router.post("/messages/groups")
async def create_group_chat(
    payload: GroupChatCreateRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    if not payload.name.strip():
        raise HTTPException(status_code=400, detail="Group name is required")

    members = set(payload.member_ids)
    members.add(current_user["user_id"])

    group_doc = {
        "group_id": str(uuid.uuid4()),
        "name": payload.name.strip(),
        "member_ids": sorted(members),
        "created_by": current_user["user_id"],
        "created_at": now_iso(),
        "messages": [],
    }
    await db.group_chats.insert_one(group_doc)
    return {"message": "Group chat created", "group": {k: v for k, v in group_doc.items() if k != "_id"}}


@api_router.get("/messages/groups")
async def get_group_chats(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    if "admin" in current_user.get("roles", []):
        query = {}
    else:
        query = {"member_ids": current_user["user_id"]}
    groups = await db.group_chats.find(query, {"_id": 0}).sort("created_at", -1).to_list(2000)
    return {"groups": groups}


@api_router.post("/messages/groups/{group_id}/join")
async def join_group_chat(
    group_id: str,
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, str]:
    group_doc = await db.group_chats.find_one({"group_id": group_id}, {"_id": 0, "group_id": 1, "member_ids": 1})
    if not group_doc:
        raise HTTPException(status_code=404, detail="Group not found")

    if current_user["user_id"] in group_doc.get("member_ids", []):
        return {"message": "You are already a member of this group"}

    await db.group_chats.update_one(
        {"group_id": group_id},
        {"$addToSet": {"member_ids": current_user["user_id"]}},
    )
    return {"message": "Joined group successfully"}


@api_router.post("/messages/groups/{group_id}/messages")
async def send_group_message(
    group_id: str,
    payload: GroupMessageCreateRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    group_doc = await db.group_chats.find_one({"group_id": group_id}, {"_id": 0})
    if not group_doc:
        raise HTTPException(status_code=404, detail="Group not found")

    is_admin = "admin" in current_user.get("roles", [])
    if not is_admin and current_user["user_id"] not in group_doc.get("member_ids", []):
        raise HTTPException(status_code=403, detail="Not a member of this group")

    msg = {
        "message_id": str(uuid.uuid4()),
        "from_user_id": current_user["user_id"],
        "content": payload.content.strip(),
        "created_at": now_iso(),
    }
    await db.group_chats.update_one({"group_id": group_id}, {"$push": {"messages": msg}})
    return {"message": "Group message sent", "data": msg}


@api_router.get("/announcements")
async def list_announcements(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    _ = current_user
    announcements = await db.announcements.find({}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return {"announcements": announcements}


@api_router.post("/announcements")
async def create_announcement(
    payload: AnnouncementCreateRequest,
    current_user: Dict[str, Any] = Depends(require_roles(["admin"])),
) -> Dict[str, Any]:
    announcement_doc = {
        "announcement_id": str(uuid.uuid4()),
        "title": payload.title.strip(),
        "message": payload.message.strip(),
        "created_by": current_user["user_id"],
        "created_at": now_iso(),
    }
    await db.announcements.insert_one(announcement_doc.copy())
    return {"message": "Announcement posted", "announcement": announcement_doc}


@api_router.get("/gamification/dashboard")
async def gamification_dashboard(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    user_doc = await db.users.find_one({"user_id": current_user["user_id"]}, {"_id": 0})
    challenges = [
        {"id": "mentor", "title": "Mentor someone today", "points": 10},
        {"id": "referral", "title": "Share one job referral", "points": 12},
        {"id": "story", "title": "Post one success story", "points": 8},
    ]

    today = datetime.now(timezone.utc).date().isoformat()
    completions = await db.challenge_completions.find(
        {"user_id": current_user["user_id"], "completed_on": today},
        {"_id": 0, "challenge_id": 1},
    ).to_list(100)
    completed_ids = {item["challenge_id"] for item in completions}

    leaderboard_docs = await db.users.find(
        {},
        {"_id": 0, "name": 1, "username": 1, "gamification_points": 1, "applauds_received": 1},
    ).sort("gamification_points", -1).to_list(20)

    badges = calculate_badges(user_doc)
    if badges != user_doc.get("badges", []):
        await db.users.update_one({"user_id": user_doc["user_id"]}, {"$set": {"badges": badges, "updated_at": now_iso()}})
        user_doc["badges"] = badges

    user_score_docs = await db.mini_game_scores.find(
        {"user_id": current_user["user_id"]},
        {"_id": 0, "game_type": 1, "best_score": 1},
    ).to_list(20)
    user_best_scores = {"tap_speed": 0, "memory_flip": 0}
    for score_doc in user_score_docs:
        user_best_scores[score_doc["game_type"]] = int(score_doc.get("best_score", 0))

    tap_scores = await db.mini_game_scores.find(
        {"game_type": "tap_speed"},
        {"_id": 0, "user_id": 1, "best_score": 1},
    ).sort("best_score", -1).to_list(10)

    memory_scores = await db.mini_game_scores.find(
        {"game_type": "memory_flip"},
        {"_id": 0, "user_id": 1, "best_score": 1},
    ).sort("best_score", -1).to_list(10)

    score_user_ids = {item["user_id"] for item in [*tap_scores, *memory_scores]}
    score_user_map: Dict[str, Dict[str, Any]] = {}
    if score_user_ids:
        score_users = await db.users.find(
            {"user_id": {"$in": list(score_user_ids)}},
            {"_id": 0, "user_id": 1, "name": 1, "username": 1},
        ).to_list(100)
        score_user_map = {item["user_id"]: item for item in score_users}

    def format_game_leaderboard(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        formatted: List[Dict[str, Any]] = []
        for item in items:
            user_info = score_user_map.get(item["user_id"], {})
            formatted.append(
                {
                    "name": user_info.get("name", "Unknown"),
                    "username": user_info.get("username", "unknown"),
                    "best_score": int(item.get("best_score", 0)),
                }
            )
        return formatted

    return {
        "user_stats": {
            "points": user_doc.get("gamification_points", 0),
            "streak": user_doc.get("streak_count", 0),
            "applauds_received": user_doc.get("applauds_received", 0),
            "referral_points": user_doc.get("referral_points", 0),
            "badges": user_doc.get("badges", []),
        },
        "daily_challenges": [
            {
                **challenge,
                "completed": challenge["id"] in completed_ids,
            }
            for challenge in challenges
        ],
        "leaderboard": leaderboard_docs,
        "mini_games": {
            "user_best_scores": user_best_scores,
            "tap_speed_leaderboard": format_game_leaderboard(tap_scores),
            "memory_flip_leaderboard": format_game_leaderboard(memory_scores),
        },
    }


@api_router.post("/gamification/challenges/{challenge_id}/complete")
async def complete_challenge(
    challenge_id: str,
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, str]:
    today_date = datetime.now(timezone.utc).date().isoformat()
    existing = await db.challenge_completions.find_one(
        {"user_id": current_user["user_id"], "challenge_id": challenge_id, "completed_on": today_date},
        {"_id": 0},
    )
    if existing:
        return {"message": "Challenge already completed today"}

    await db.challenge_completions.insert_one(
        {
            "completion_id": str(uuid.uuid4()),
            "user_id": current_user["user_id"],
            "challenge_id": challenge_id,
            "completed_on": today_date,
            "created_at": now_iso(),
        }
    )

    user_doc = await db.users.find_one({"user_id": current_user["user_id"]}, {"_id": 0})
    last_completion_date = user_doc.get("last_challenge_date")
    new_streak = 1
    if last_completion_date:
        previous = datetime.fromisoformat(last_completion_date).date()
        current = datetime.now(timezone.utc).date()
        if (current - previous).days == 1:
            new_streak = user_doc.get("streak_count", 0) + 1
        elif (current - previous).days == 0:
            new_streak = user_doc.get("streak_count", 0)

    points = user_doc.get("gamification_points", 0) + 10
    await db.users.update_one(
        {"user_id": current_user["user_id"]},
        {
            "$set": {
                "gamification_points": points,
                "streak_count": new_streak,
                "last_challenge_date": datetime.now(timezone.utc).isoformat(),
                "updated_at": now_iso(),
            }
        },
    )
    return {"message": "Challenge completed and points awarded"}


@api_router.post("/gamification/applaud")
async def applaud_user(
    payload: ApplaudRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, str]:
    if payload.to_user_id == current_user["user_id"]:
        raise HTTPException(status_code=400, detail="You cannot applaud yourself")

    target_user = await db.users.find_one({"user_id": payload.to_user_id}, {"_id": 0})
    if not target_user:
        raise HTTPException(status_code=404, detail="Target user not found")

    await db.applauds.insert_one(
        {
            "applaud_id": str(uuid.uuid4()),
            "from_user_id": current_user["user_id"],
            "to_user_id": payload.to_user_id,
            "reason": payload.reason,
            "created_at": now_iso(),
        }
    )
    await db.users.update_one(
        {"user_id": payload.to_user_id},
        {
            "$inc": {
                "applauds_received": 1,
                "gamification_points": 5,
            },
            "$set": {"updated_at": now_iso()},
        },
    )
    return {"message": "Applaud sent successfully"}


@api_router.post("/gamification/referrals")
async def create_referral(
    payload: ReferralCreateRequest,
    current_user: Dict[str, Any] = Depends(require_roles(["alumni", "admin"])),
) -> Dict[str, Any]:
    student = await db.users.find_one({"user_id": payload.student_id}, {"_id": 0, "user_id": 1})
    if not student:
        raise HTTPException(status_code=404, detail="Student profile not found")

    referral_doc = {
        "referral_id": str(uuid.uuid4()),
        "referred_by": current_user["user_id"],
        "student_id": payload.student_id,
        "company": payload.company,
        "job_title": payload.job_title,
        "status": payload.status,
        "created_at": now_iso(),
    }
    await db.referrals.insert_one(referral_doc.copy())

    if payload.status == "successful":
        await db.users.update_one(
            {"user_id": current_user["user_id"]},
            {
                "$inc": {
                    "successful_referrals": 1,
                    "referral_points": 20,
                    "gamification_points": 20,
                },
                "$set": {"updated_at": now_iso()},
            },
        )

    return {"message": "Referral recorded", "referral": referral_doc}


@api_router.post("/gamification/mini-games/score")
async def save_mini_game_score(
    payload: MiniGameScoreRequest,
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    if payload.score < 0:
        raise HTTPException(status_code=400, detail="Score cannot be negative")

    now = now_iso()
    existing = await db.mini_game_scores.find_one(
        {"user_id": current_user["user_id"], "game_type": payload.game_type},
        {"_id": 0},
    )

    is_new_best = False
    if not existing:
        is_new_best = True
        await db.mini_game_scores.insert_one(
            {
                "score_id": str(uuid.uuid4()),
                "user_id": current_user["user_id"],
                "game_type": payload.game_type,
                "best_score": payload.score,
                "last_score": payload.score,
                "play_count": 1,
                "last_played_at": now,
                "created_at": now,
                "updated_at": now,
            }
        )
    else:
        previous_best = int(existing.get("best_score", 0))
        is_new_best = payload.score > previous_best
        update_payload: Dict[str, Any] = {
            "last_score": payload.score,
            "last_played_at": now,
            "updated_at": now,
        }
        if is_new_best:
            update_payload["best_score"] = payload.score

        await db.mini_game_scores.update_one(
            {"user_id": current_user["user_id"], "game_type": payload.game_type},
            {"$set": update_payload, "$inc": {"play_count": 1}},
        )

    if is_new_best:
        await db.users.update_one(
            {"user_id": current_user["user_id"]},
            {"$inc": {"gamification_points": 2}, "$set": {"updated_at": now}},
        )

    updated_score_doc = await db.mini_game_scores.find_one(
        {"user_id": current_user["user_id"], "game_type": payload.game_type},
        {"_id": 0},
    )
    return {
        "message": "Mini game score saved",
        "game_type": payload.game_type,
        "last_score": int(updated_score_doc.get("last_score", 0)),
        "best_score": int(updated_score_doc.get("best_score", 0)),
        "is_new_best": is_new_best,
    }


@api_router.get("/gamification/mini-games/leaderboard")
async def get_mini_game_leaderboard(
    game_type: Literal["tap_speed", "memory_flip"] = "tap_speed",
    current_user: Dict[str, Any] = Depends(get_current_user),
) -> Dict[str, Any]:
    _ = current_user
    leaderboard_docs = await db.mini_game_scores.find(
        {"game_type": game_type},
        {"_id": 0, "user_id": 1, "best_score": 1},
    ).sort("best_score", -1).to_list(20)

    user_ids = [entry["user_id"] for entry in leaderboard_docs]
    user_map: Dict[str, Dict[str, Any]] = {}
    if user_ids:
        users = await db.users.find(
            {"user_id": {"$in": user_ids}},
            {"_id": 0, "user_id": 1, "name": 1, "username": 1},
        ).to_list(50)
        user_map = {item["user_id"]: item for item in users}

    formatted = [
        {
            "rank": index + 1,
            "name": user_map.get(item["user_id"], {}).get("name", "Unknown"),
            "username": user_map.get(item["user_id"], {}).get("username", "unknown"),
            "best_score": int(item.get("best_score", 0)),
        }
        for index, item in enumerate(leaderboard_docs)
    ]
    return {"game_type": game_type, "leaderboard": formatted}


@api_router.get("/gamification/leaderboard")
async def get_leaderboard(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    _ = current_user
    leaderboard = await db.users.find(
        {},
        {
            "_id": 0,
            "name": 1,
            "username": 1,
            "gamification_points": 1,
            "successful_referrals": 1,
            "applauds_received": 1,
            "badges": 1,
        },
    ).sort("gamification_points", -1).to_list(50)
    return {"leaderboard": leaderboard}


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ["CORS_ORIGINS"].split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
async def shutdown_db_client() -> None:
    client.close()