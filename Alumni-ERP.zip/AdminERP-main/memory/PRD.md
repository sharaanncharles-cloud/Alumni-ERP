# PRD — AlumniConnect College Alumni Platform

## Original Problem Statement
Build a full alumni platform for colleges with:
- Default admin account (`admin` / `butteryellow`), mandatory first-login password change
- Admin control over student/alumni/teacher accounts
- Multi-role assignment (student/alumni/admin/teacher)
- Student and alumni profile management (career history, internships, companies, committees, groups, bio)
- Password reset workflows and secure credential handling
- Messaging (direct and group), announcements
- Gamification (daily challenges, streaks, applauds, referrals, badges, leaderboard)
- Admin analytics with bar/pie charts for placement outcomes by course/company
- Landing visual style matching provided reference vibe (modernized)

## User Choices Captured
1. Full build now (not MVP)
2. Password reset email provider: Resend
3. Login for admin + student + alumni now
4. Admin first-login password change mandatory
5. Design style: same screenshot vibe, modernized spacing/components
6. Updated default admin password to `butteryellow`
7. Mentors are alumni users (`mentorship_available = true`), not a separate role
8. Admin and mentor profiles should be minimal (name + department focus)
9. `About` removed in favor of single `bio` field
10. Keep small game as last section

## Architecture Decisions
- **Frontend:** React + React Router + Tailwind + Shadcn UI + Recharts + Sonner
- **Backend:** FastAPI + MongoDB (Motor) + JWT auth
- **Security:** bcrypt password hashing, role checks, token-based auth
- **Data model:** single `users` collection with multi-role + profile fields, plus collections for messages, groups, announcements, referrals, applauds, challenge completions, password reset tokens
- **Email:** Resend integration with safe fallback preview reset link when key is absent

## User Personas
- **Admin/Placement Team:** manage accounts, roles, credentials, analytics, announcements
- **Student:** maintain profile, seek mentors, message alumni, participate in gamification
- **Alumni:** mentorship, referrals, networking, engagement recognition
- **Teacher:** optional role access for academic/committee management

## Core Requirements (Static)
- Secure login and password lifecycle
- Admin-controlled user creation and role assignment
- Career-focused profile system
- Community communication tools
- Engagement and recognition mechanics
- Placement-focused analytics dashboard

## What’s Implemented (as of 2026-03-16)
- Full role-based authentication with JWT and forced first-login password change
- Default admin seeding (`admin` / `admin123`) with mandatory reset flag
- Admin user management: create users, assign/update roles, reset user passwords
- Forgot-password + reset-password flows with token expiry and Resend send hook
- Student/alumni profile CRUD (self-edit) and searchable alumni directory
- Direct messaging, group chats, and admin announcements
- Gamification APIs and UI: challenges, streaks, applauds, referrals, badges, leaderboard
- Analytics APIs + UI charts: placements by course (bar) and company (pie)
- Responsive landing page and dashboard shell aligned to chosen visual direction
- Added robust `data-testid` coverage across major interactive/critical UI elements
- Updated default admin credential behavior to `admin` / `butteryellow`
- Simplified profile semantics: removed `about` usage and standardized on `bio`
- Added `department` field and minimal-profile mode for admin and mentor-style users
- Updated UI to be more colorful/characterful while preserving the dashboard structure
- Added a mini tap game at the bottom of Gamification page as the last engagement element
- Added admin soft-delete + restore flow for users, completing add/update/remove management
- Added analytics demo fallback data when placement records are empty so charts always demonstrate behavior
- Updated admin area visual backdrop to a stronger plum theme for higher contrast and character
- Reset default data to exactly 4 core accounts (Admin + Atul + Annie + Marie) and enabled realistic profile images for the three character profiles (Atul marked as mentor)
- Added Emma (`username: emma`) as alumni with placed-from-college status and full bio, and updated Atul login password to `atul@123`
- Improved messaging UX: multi-line compose (Enter new line, Ctrl/Cmd+Enter send), clearer sent-message visibility, group ID sharing/copy flow, and join-by-group-ID support
- Added two mini games inside Gamification page (Tap Speed + Memory Flip Cards) with both local gameplay feedback and backend-saved best scores/leaderboards

## Prioritized Backlog
### P0 (High Priority)
- Add admin edit modal for full user profile updates (currently create/reset/role-focused)
- Add robust email delivery config UI + delivery status tracking
- Add pagination/filter chips for very large directories and user lists

### P1 (Medium Priority)
- Teacher-specific dashboard and permissions scope
- Referral success workflow with student outcomes and audit trail views
- Advanced analytics export (CSV/PDF) and date-range reports

### P2 (Lower Priority)
- Optional 2FA for admin and privileged accounts
- In-app notification center
- Profile endorsements and richer alumni networking graph

## Next Tasks
1. Connect real Resend API key + sender domain for production email delivery.
2. Add admin-friendly edit workflow for existing user full profile fields.
3. Add analytics filters by batch/course/year and downloadable reports.
4. Enhance messaging with read receipts and search.
5. Add moderation tools for announcements and community content.
