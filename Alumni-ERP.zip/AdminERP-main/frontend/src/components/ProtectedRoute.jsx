import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

export const ProtectedRoute = ({ requiredRole, children }) => {
  const { user, loading, hasRole } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center text-lg font-medium"
        data-testid="auth-loading-state"
      >
        Loading AlumniConnect...
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  const isChangePasswordRoute = location.pathname === "/app/change-password";
  if (user.must_change_password && !isChangePasswordRoute) {
    return <Navigate to="/app/change-password" replace />;
  }

  if (requiredRole && !hasRole(requiredRole)) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6" data-testid="unauthorized-view">
        <div className="rounded-2xl bg-white p-8 shadow-lg max-w-xl text-center">
          <h2 className="text-2xl font-semibold mb-3">Access restricted</h2>
          <p className="text-slate-600" data-testid="unauthorized-message">
            You need {requiredRole} role permission to access this section.
          </p>
        </div>
      </div>
    );
  }

  return children || <Outlet />;
};
