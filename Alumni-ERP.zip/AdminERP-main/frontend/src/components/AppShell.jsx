import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { LogOut, ShieldCheck, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/context/AuthContext";

const navItems = [
  { to: "/app", label: "Overview", testId: "nav-overview-link" },
  { to: "/app/profile", label: "My Profile", testId: "nav-profile-link" },
  { to: "/app/directory", label: "Alumni Directory", testId: "nav-directory-link" },
  { to: "/app/messaging", label: "Messaging", testId: "nav-messaging-link" },
  { to: "/app/gamification", label: "Gamification", testId: "nav-gamification-link" },
  { to: "/app/analytics", label: "Analytics", adminOnly: true, testId: "nav-analytics-link" },
  { to: "/app/admin/users", label: "Manage Users", adminOnly: true, testId: "nav-manage-users-link" },
  {
    to: "/app/change-password",
    label: "Change Password",
    testId: "nav-change-password-link",
  },
];

export const AppShell = () => {
  const { user, logout, hasRole } = useAuth();
  const navigate = useNavigate();

  const onLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_right,_#f4c08d_0%,_#5b1e62_32%,_#3d1046_65%,_#2a092f_100%)]" data-testid="app-shell">
      <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
        <header className="mb-6 rounded-2xl border border-[#f3d1ff] bg-white/85 backdrop-blur-xl p-4 sm:p-6 flex flex-wrap gap-4 items-center justify-between shadow-[0_10px_30px_rgba(76,29,149,0.08)]">
          <div>
            <Link to="/" className="inline-flex items-center gap-2 text-[#1e3a8a]" data-testid="shell-logo-link">
              <Sparkles className="h-5 w-5" />
              <span className="font-semibold text-xl">AlumniConnect</span>
            </Link>
            <p className="text-sm text-slate-600 mt-1" data-testid="shell-welcome-text">
              Welcome, {user?.name || user?.username}
              {user?.department ? ` · ${user.department}` : ""}
            </p>
          </div>

          <div className="flex flex-wrap gap-2 items-center">
            <img
              src={user?.profile_image_url || "https://placehold.co/80x80?text=User"}
              alt={user?.name || user?.username}
              className="h-10 w-10 rounded-full object-cover border border-slate-200"
              data-testid="shell-user-image"
            />
            {user?.roles?.map((role) => (
              <Badge key={role} className="capitalize" data-testid={`shell-role-badge-${role}`}>
                {role}
              </Badge>
            ))}
            {hasRole("admin") && (
              <Badge className="bg-[#1e3a8a] text-white" data-testid="shell-admin-indicator">
                <ShieldCheck className="h-4 w-4 mr-1" />
                Admin Access
              </Badge>
            )}
            <Button variant="outline" onClick={onLogout} data-testid="shell-logout-button">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </header>

        <div className="grid lg:grid-cols-[280px_1fr] gap-6 lg:gap-8">
          <aside className="rounded-2xl border border-[#efcdfa] bg-white/90 backdrop-blur-xl p-4 shadow-[0_8px_24px_rgba(126,34,206,0.08)] h-fit" data-testid="app-sidebar">
            <nav className="space-y-2" data-testid="app-nav">
              {navItems.map((item) => {
                if (item.adminOnly && !hasRole("admin")) return null;
                return (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    end={item.to === "/app"}
                    data-testid={item.testId}
                    className={({ isActive }) =>
                      [
                        "block rounded-xl px-4 py-3 text-sm font-medium transition-colors duration-300",
                        isActive
                          ? "bg-gradient-to-r from-[#1e3a8a] to-[#7c3aed] text-white"
                          : "bg-slate-100/85 text-slate-700 hover:bg-[#ffd7eb]",
                      ].join(" ")
                    }
                  >
                    {item.label}
                  </NavLink>
                );
              })}
            </nav>
          </aside>

          <main className="rounded-2xl border border-[#f2d3ff] bg-white/90 backdrop-blur-xl p-4 sm:p-6 lg:p-8 shadow-[0_8px_24px_rgba(15,23,42,0.08)]" data-testid="app-main-content">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
};
