import { useEffect, useState } from "react";
import { api, getApiError } from "@/api";
import { toast } from "@/components/ui/sonner";
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const chartColors = ["#1e3a8a", "#facc15", "#ec4899", "#10b981", "#3b82f6", "#f97316"];

export default function AnalyticsPage() {
  const [analytics, setAnalytics] = useState(null);

  useEffect(() => {
    const loadAnalytics = async () => {
      try {
        const response = await api.get("/admin/analytics");
        setAnalytics(response.data);
      } catch (error) {
        toast.error(getApiError(error, "Could not load analytics"));
      }
    };

    loadAnalytics();
  }, []);

  return (
    <section data-testid="analytics-page">
      <h1 className="font-heading text-4xl sm:text-5xl text-[#1e3a8a]" data-testid="analytics-title">
        Placement & Engagement Analytics
      </h1>
      <p className="text-base text-slate-600 mt-3 mb-8" data-testid="analytics-description">
        Visualize placements by course and company using bar and pie charts.
      </p>

      {analytics?.is_mock_data && (
        <div
          className="mb-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800"
          data-testid="analytics-mock-data-banner"
        >
          Showing sample placement analytics data for demo preview.
        </div>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4" data-testid="analytics-metrics-grid">
        <MetricCard label="Total Users" value={analytics?.totals?.users || 0} testId="analytics-total-users" />
        <MetricCard label="Students" value={analytics?.totals?.students || 0} testId="analytics-total-students" />
        <MetricCard label="Alumni" value={analytics?.totals?.alumni || 0} testId="analytics-total-alumni" />
        <MetricCard label="Referrals" value={analytics?.totals?.referrals || 0} testId="analytics-total-referrals" />
      </div>

      <div className="grid xl:grid-cols-2 gap-6 mt-6">
        <section className="rounded-2xl border border-slate-200 bg-white p-5" data-testid="analytics-course-bar-chart-card">
          <h2 className="text-lg font-semibold mb-4" data-testid="analytics-course-bar-title">Placements by Course</h2>
          <div className="h-[320px]" data-testid="analytics-course-bar-chart-container">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics?.placements_by_course || []}>
                <XAxis dataKey="course" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="placements" radius={[6, 6, 0, 0]} fill="#1e3a8a" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-5" data-testid="analytics-company-pie-chart-card">
          <h2 className="text-lg font-semibold mb-4" data-testid="analytics-company-pie-title">Placements by Company</h2>
          <div className="h-[320px]" data-testid="analytics-company-pie-chart-container">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={analytics?.placements_by_company || []} dataKey="placements" nameKey="company" outerRadius={100} label>
                  {(analytics?.placements_by_company || []).map((entry, index) => (
                    <Cell key={`cell-${entry.company}`} fill={chartColors[index % chartColors.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </section>
      </div>

      <section className="rounded-2xl border border-slate-200 bg-white p-5 mt-6" data-testid="analytics-top-leaderboard-card">
        <h2 className="text-lg font-semibold mb-4" data-testid="analytics-top-leaderboard-title">Top Engagement Leaders</h2>
        <div className="space-y-2" data-testid="analytics-top-leaderboard-list">
          {(analytics?.leaderboard || []).map((entry, index) => (
            <div key={`${entry.name}-${index}`} className="rounded-xl border border-slate-200 px-4 py-3 flex justify-between items-center" data-testid={`analytics-top-leader-row-${index + 1}`}>
              <p className="text-sm" data-testid={`analytics-top-leader-name-${index + 1}`}>
                #{index + 1} {entry.name}
              </p>
              <p className="text-sm font-semibold text-[#1e3a8a]" data-testid={`analytics-top-leader-points-${index + 1}`}>
                {entry.points} points
              </p>
            </div>
          ))}
        </div>
      </section>
    </section>
  );
}

const MetricCard = ({ label, value, testId }) => (
  <article className="rounded-2xl border border-slate-200 bg-white p-4" data-testid={testId}>
    <p className="text-sm text-slate-500" data-testid={`${testId}-label`}>{label}</p>
    <p className="text-2xl font-semibold text-[#1e3a8a]" data-testid={`${testId}-value`}>{value}</p>
  </article>
);
