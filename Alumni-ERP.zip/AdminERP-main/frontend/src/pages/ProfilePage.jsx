import { useEffect, useState } from "react";
import { api, getApiError, splitCsv } from "@/api";
import { toast } from "@/components/ui/sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";

const defaultProfile = {
  name: "",
  profile_image_url: "",
  department: "",
  batch: "",
  course: "",
  degree_level: "",
  roles: [],
  passed_out: "",
  currently_pursuing: false,
  placed_from_college: false,
  companies_worked_in: "",
  internship_done: "",
  interests: "",
  committees: "",
  groups: "",
  personal_email: "",
  college_email: "",
  current_role: "",
  current_company: "",
  bio: "",
  mentorship_available: false,
  mentorship_categories: "",
};

export default function ProfilePage() {
  const { refreshProfile } = useAuth();
  const [profile, setProfile] = useState(defaultProfile);
  const [saving, setSaving] = useState(false);
  const minimalProfileMode = profile.roles?.includes("admin") || profile.mentorship_available;

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const response = await api.get("/profiles/me");
        const data = response.data.profile;
        setProfile({
          ...defaultProfile,
          ...data,
          companies_worked_in: (data.companies_worked_in || []).join(", "),
          internship_done: (data.internship_done || []).join(", "),
          interests: (data.interests || []).join(", "),
          committees: (data.committees || []).join(", "),
          groups: (data.groups || []).join(", "),
          mentorship_categories: (data.mentorship_categories || []).join(", "),
        });
      } catch (error) {
        toast.error(getApiError(error, "Could not load profile"));
      }
    };

    loadProfile();
  }, []);

  const saveProfile = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      const payload = {
        ...profile,
        companies_worked_in: splitCsv(profile.companies_worked_in),
        internship_done: splitCsv(profile.internship_done),
        interests: splitCsv(profile.interests),
        committees: splitCsv(profile.committees),
        groups: splitCsv(profile.groups),
        mentorship_categories: splitCsv(profile.mentorship_categories),
        personal_email: profile.personal_email?.trim() ? profile.personal_email.trim() : null,
        college_email: profile.college_email?.trim() ? profile.college_email.trim() : null,
      };
      const response = await api.put("/profiles/me", payload);
      toast.success(response.data.message || "Profile updated");
      await refreshProfile();
    } catch (error) {
      toast.error(getApiError(error, "Could not save profile"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <section data-testid="profile-page">
      <h1 className="font-heading text-4xl sm:text-5xl text-[#1e3a8a]" data-testid="profile-page-title">
        My Profile
      </h1>
      <p className="text-base text-slate-600 mt-3 mb-8" data-testid="profile-page-description">
        Keep your details updated so peers, mentors, and admins can connect meaningfully.
      </p>

      <form onSubmit={saveProfile} className="space-y-4 rounded-2xl border border-slate-200 bg-white p-6" data-testid="profile-form">
        <div className="grid md:grid-cols-2 gap-4">
          <Field id="name" label="Name" value={profile.name} onChange={(v) => setProfile((p) => ({ ...p, name: v }))} testId="profile-name" />
          <Field id="profile_image_url" label="Profile Image URL" value={profile.profile_image_url} onChange={(v) => setProfile((p) => ({ ...p, profile_image_url: v }))} testId="profile-image-url" />
          <Field id="department" label="Department" value={profile.department} onChange={(v) => setProfile((p) => ({ ...p, department: v }))} testId="profile-department" />
          <Field id="personal_email" label="Personal Email" value={profile.personal_email} onChange={(v) => setProfile((p) => ({ ...p, personal_email: v }))} testId="profile-personal-email" />
          <Field id="college_email" label="College Email" value={profile.college_email} onChange={(v) => setProfile((p) => ({ ...p, college_email: v }))} testId="profile-college-email" />
          <Field id="current_role" label="Current Role" value={profile.current_role} onChange={(v) => setProfile((p) => ({ ...p, current_role: v }))} testId="profile-current-role" />
          <Field id="current_company" label="Current Company" value={profile.current_company} onChange={(v) => setProfile((p) => ({ ...p, current_company: v }))} testId="profile-current-company" />
          <Field id="interests" label="Interests" value={profile.interests} onChange={(v) => setProfile((p) => ({ ...p, interests: v }))} testId="profile-interests" />
          <Field id="mentorship_categories" label="Mentorship Categories" value={profile.mentorship_categories} onChange={(v) => setProfile((p) => ({ ...p, mentorship_categories: v }))} testId="profile-mentorship-categories" />

          {!minimalProfileMode && (
            <>
              <Field id="batch" label="Batch" value={profile.batch} onChange={(v) => setProfile((p) => ({ ...p, batch: v }))} testId="profile-batch" />
              <Field id="course" label="Course" value={profile.course} onChange={(v) => setProfile((p) => ({ ...p, course: v }))} testId="profile-course" />
              <Field id="degree_level" label="PG/UG/Doctorate" value={profile.degree_level} onChange={(v) => setProfile((p) => ({ ...p, degree_level: v }))} testId="profile-degree" />
              <Field id="passed_out" label="Passed Out" value={profile.passed_out} onChange={(v) => setProfile((p) => ({ ...p, passed_out: v }))} testId="profile-passed-out" />
              <Field id="companies_worked_in" label="Companies Worked In" value={profile.companies_worked_in} onChange={(v) => setProfile((p) => ({ ...p, companies_worked_in: v }))} testId="profile-companies" />
              <Field id="internship_done" label="Internships" value={profile.internship_done} onChange={(v) => setProfile((p) => ({ ...p, internship_done: v }))} testId="profile-internships" />
              <Field id="committees" label="Committees" value={profile.committees} onChange={(v) => setProfile((p) => ({ ...p, committees: v }))} testId="profile-committees" />
              <Field id="groups" label="Groups" value={profile.groups} onChange={(v) => setProfile((p) => ({ ...p, groups: v }))} testId="profile-groups" />
            </>
          )}
        </div>

        <div className="flex flex-wrap gap-6 text-sm">
          <label className="flex items-center gap-2" data-testid="profile-currently-pursuing-toggle">
            <input type="checkbox" checked={profile.currently_pursuing} onChange={(event) => setProfile((p) => ({ ...p, currently_pursuing: event.target.checked }))} data-testid="profile-currently-pursuing-checkbox" />
            Currently pursuing
          </label>
          <label className="flex items-center gap-2" data-testid="profile-placed-from-college-toggle">
            <input type="checkbox" checked={profile.placed_from_college} onChange={(event) => setProfile((p) => ({ ...p, placed_from_college: event.target.checked }))} data-testid="profile-placed-from-college-checkbox" />
            Placed from college
          </label>
          <label className="flex items-center gap-2" data-testid="profile-mentorship-available-toggle">
            <input type="checkbox" checked={profile.mentorship_available} onChange={(event) => setProfile((p) => ({ ...p, mentorship_available: event.target.checked }))} data-testid="profile-mentorship-available-checkbox" />
            Available for mentorship
          </label>
        </div>

        <div className="space-y-2">
          <Label htmlFor="bio" data-testid="profile-bio-label">Bio</Label>
          <Textarea id="bio" value={profile.bio} onChange={(event) => setProfile((p) => ({ ...p, bio: event.target.value }))} data-testid="profile-bio-input" />
        </div>

        {profile.profile_image_url && (
          <div className="space-y-2" data-testid="profile-image-preview-container">
            <Label data-testid="profile-image-preview-label">Profile image preview</Label>
            <img
              src={profile.profile_image_url}
              alt="Profile preview"
              className="h-24 w-24 rounded-full object-cover border border-slate-200"
              data-testid="profile-image-preview"
            />
          </div>
        )}

        <Button type="submit" disabled={saving} data-testid="profile-save-button">
          {saving ? "Saving..." : "Save Profile"}
        </Button>
      </form>
    </section>
  );
}

const Field = ({ id, label, value, onChange, testId }) => (
  <div className="space-y-2">
    <Label htmlFor={id} data-testid={`${testId}-label`}>{label}</Label>
    <Input id={id} value={value || ""} onChange={(event) => onChange(event.target.value)} data-testid={`${testId}-input`} />
  </div>
);
