import { useEffect, useMemo, useState } from "react";
import { api, getApiError, splitCsv } from "@/api";
import { toast } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";

const roles = ["student", "alumni", "admin", "teacher"];

const initialForm = {
  name: "",
  department: "",
  username: "",
  profile_image_url: "",
  roles: ["student"],
  batch: "",
  course: "",
  currently_pursuing: true,
  degree_level: "UG",
  passed_out: "",
  placed_from_college: false,
  companies_worked_in: "",
  internship_done: "",
  interests: "",
  bio: "",
  personal_email: "",
  college_email: "",
  committees: "",
  groups: "",
  mentorship_available: false,
  mentorship_categories: "",
  current_role: "",
  current_company: "",
};

export default function AdminUsersPage() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState(initialForm);
  const [editForm, setEditForm] = useState(null);
  const [editingUser, setEditingUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [search, setSearch] = useState("");
  const minimalProfileMode = form.roles.includes("admin") || form.mentorship_available;

  const loadUsers = async () => {
    setLoading(true);
    try {
      const response = await api.get("/admin/users");
      setUsers(response.data.users || []);
    } catch (error) {
      toast.error(getApiError(error, "Could not load users"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const filteredUsers = useMemo(() => {
    if (!search.trim()) return users;
    return users.filter((user) => {
      const value = search.toLowerCase();
      return (
        user.name?.toLowerCase().includes(value) ||
        user.username?.toLowerCase().includes(value) ||
        user.course?.toLowerCase().includes(value)
      );
    });
  }, [users, search]);

  const toggleRole = (role) => {
    setForm((prev) => {
      const roleSet = new Set(prev.roles);
      if (roleSet.has(role)) {
        roleSet.delete(role);
      } else {
        roleSet.add(role);
      }
      if (roleSet.size === 0) roleSet.add("student");
      return { ...prev, roles: [...roleSet] };
    });
  };

  const onCreateUser = async (event) => {
    event.preventDefault();
    setCreating(true);
    try {
      const payload = {
        ...form,
        companies_worked_in: splitCsv(form.companies_worked_in),
        internship_done: splitCsv(form.internship_done),
        interests: splitCsv(form.interests),
        committees: splitCsv(form.committees),
        groups: splitCsv(form.groups),
        mentorship_categories: splitCsv(form.mentorship_categories),
        profile_image_url: form.profile_image_url?.trim() ? form.profile_image_url.trim() : null,
        personal_email: form.personal_email?.trim() ? form.personal_email.trim() : null,
        college_email: form.college_email?.trim() ? form.college_email.trim() : null,
      };
      const response = await api.post("/admin/users", payload);
      toast.success(response.data.message || "User created");
      if (response.data.temporary_password) {
        toast.info(`Temporary password: ${response.data.temporary_password}`);
      }
      setForm(initialForm);
      await loadUsers();
    } catch (error) {
      toast.error(getApiError(error, "Could not create user"));
    } finally {
      setCreating(false);
    }
  };

  const resetUserPassword = async (userId) => {
    try {
      const response = await api.post(`/admin/users/${userId}/reset-password`, {});
      toast.success(response.data.message || "Temporary password reset");
      if (response.data.temporary_password) {
        toast.info(`Temporary password: ${response.data.temporary_password}`);
      }
    } catch (error) {
      toast.error(getApiError(error, "Could not reset password"));
    }
  };

  const promoteToAlumni = async (user) => {
    const nextRoles = user.roles.includes("alumni")
      ? user.roles.filter((role) => role !== "alumni")
      : [...user.roles, "alumni"];

    if (nextRoles.length === 0) {
      toast.error("User must have at least one role");
      return;
    }

    try {
      await api.post(`/admin/users/${user.user_id}/roles`, { roles: nextRoles });
      toast.success("Roles updated");
      await loadUsers();
    } catch (error) {
      toast.error(getApiError(error, "Could not update roles"));
    }
  };

  const startEditUser = (user) => {
    setEditingUser(user);
    setEditForm({
      name: user.name || "",
      department: user.department || "",
      profile_image_url: user.profile_image_url || "",
      bio: user.bio || "",
      current_role: user.current_role || "",
      current_company: user.current_company || "",
      personal_email: user.personal_email || "",
      college_email: user.college_email || "",
      batch: user.batch || "",
      course: user.course || "",
      interests: (user.interests || []).join(", "),
      mentorship_categories: (user.mentorship_categories || []).join(", "),
      mentorship_available: Boolean(user.mentorship_available),
    });
  };

  const saveUserUpdate = async (event) => {
    event.preventDefault();
    if (!editingUser || !editForm) return;
    setUpdating(true);
    try {
      const payload = {
        name: editForm.name,
        department: editForm.department,
        profile_image_url: editForm.profile_image_url?.trim() ? editForm.profile_image_url.trim() : null,
        bio: editForm.bio,
        current_role: editForm.current_role,
        current_company: editForm.current_company,
        personal_email: editForm.personal_email?.trim() ? editForm.personal_email.trim() : null,
        college_email: editForm.college_email?.trim() ? editForm.college_email.trim() : null,
        batch: editForm.batch || null,
        course: editForm.course || null,
        interests: splitCsv(editForm.interests),
        mentorship_categories: splitCsv(editForm.mentorship_categories),
        mentorship_available: Boolean(editForm.mentorship_available),
      };
      const response = await api.put(`/admin/users/${editingUser.user_id}`, payload);
      toast.success(response.data.message || "User updated");
      setEditingUser(null);
      setEditForm(null);
      await loadUsers();
    } catch (error) {
      toast.error(getApiError(error, "Could not update user"));
    } finally {
      setUpdating(false);
    }
  };

  const toggleUserActive = async (user) => {
    if (user.username === "admin") {
      toast.error("Default admin cannot be deactivated");
      return;
    }
    try {
      if (user.is_active === false) {
        const response = await api.post(`/admin/users/${user.user_id}/restore`);
        toast.success(response.data.message || "User restored");
      } else {
        const response = await api.delete(`/admin/users/${user.user_id}`);
        toast.success(response.data.message || "User deactivated");
      }
      await loadUsers();
    } catch (error) {
      toast.error(getApiError(error, "Could not update user status"));
    }
  };

  return (
    <section data-testid="admin-users-page">
      <h1 className="font-heading text-4xl sm:text-5xl text-[#1e3a8a]" data-testid="admin-users-title">
        User Management
      </h1>
      <p className="text-base text-slate-600 mt-3 mb-7" data-testid="admin-users-description">
        Add, update, remove, and restore student/alumni/teacher/admin accounts with full role controls.
      </p>

      {editingUser && editForm && (
        <form
          onSubmit={saveUserUpdate}
          className="rounded-2xl border border-[#f0d7ff] bg-white p-5 mb-6 space-y-4"
          data-testid="admin-edit-user-form"
        >
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-lg font-semibold" data-testid="admin-edit-user-title">
              Edit User: {editingUser.username}
            </h2>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setEditingUser(null);
                setEditForm(null);
              }}
              data-testid="admin-edit-user-cancel-button"
            >
              Cancel
            </Button>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <Field id="edit-name" label="Name" value={editForm.name} onChange={(value) => setEditForm((prev) => ({ ...prev, name: value }))} testId="admin-edit-name" />
            <Field id="edit-department" label="Department" value={editForm.department} onChange={(value) => setEditForm((prev) => ({ ...prev, department: value }))} testId="admin-edit-department" />
            <Field id="edit-profile-image" label="Profile Image URL" value={editForm.profile_image_url} onChange={(value) => setEditForm((prev) => ({ ...prev, profile_image_url: value }))} testId="admin-edit-profile-image" />
            <Field id="edit-personal-email" label="Personal Email" value={editForm.personal_email} onChange={(value) => setEditForm((prev) => ({ ...prev, personal_email: value }))} testId="admin-edit-personal-email" />
            <Field id="edit-college-email" label="College Email" value={editForm.college_email} onChange={(value) => setEditForm((prev) => ({ ...prev, college_email: value }))} testId="admin-edit-college-email" />
            <Field id="edit-current-role" label="Current Role" value={editForm.current_role} onChange={(value) => setEditForm((prev) => ({ ...prev, current_role: value }))} testId="admin-edit-current-role" />
            <Field id="edit-current-company" label="Current Company" value={editForm.current_company} onChange={(value) => setEditForm((prev) => ({ ...prev, current_company: value }))} testId="admin-edit-current-company" />
            <Field id="edit-batch" label="Batch" value={editForm.batch} onChange={(value) => setEditForm((prev) => ({ ...prev, batch: value }))} testId="admin-edit-batch" />
            <Field id="edit-course" label="Course" value={editForm.course} onChange={(value) => setEditForm((prev) => ({ ...prev, course: value }))} testId="admin-edit-course" />
            <Field id="edit-interests" label="Interests" value={editForm.interests} onChange={(value) => setEditForm((prev) => ({ ...prev, interests: value }))} testId="admin-edit-interests" />
            <Field id="edit-mentorship-categories" label="Mentorship Categories" value={editForm.mentorship_categories} onChange={(value) => setEditForm((prev) => ({ ...prev, mentorship_categories: value }))} testId="admin-edit-mentorship-categories" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-bio" data-testid="admin-edit-bio-label">Bio</Label>
            <Textarea
              id="edit-bio"
              value={editForm.bio}
              onChange={(event) => setEditForm((prev) => ({ ...prev, bio: event.target.value }))}
              data-testid="admin-edit-bio-input"
            />
          </div>

          <label className="flex items-center gap-2 text-sm" data-testid="admin-edit-mentor-toggle">
            <input
              type="checkbox"
              checked={editForm.mentorship_available}
              onChange={(event) => setEditForm((prev) => ({ ...prev, mentorship_available: event.target.checked }))}
              data-testid="admin-edit-mentor-checkbox"
            />
            Mentorship available
          </label>

          <Button type="submit" disabled={updating} data-testid="admin-edit-user-save-button">
            {updating ? "Saving..." : "Save Updates"}
          </Button>
        </form>
      )}

      <div className="grid xl:grid-cols-[1.2fr_1fr] gap-6">
        <form onSubmit={onCreateUser} className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4" data-testid="admin-create-user-form">
          <h2 className="text-lg font-semibold" data-testid="admin-create-user-form-title">Create New Account</h2>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Name" id="name" value={form.name} onChange={(v) => setForm((p) => ({ ...p, name: v }))} testId="admin-create-name" />
            <Field label="Department" id="department" value={form.department} onChange={(v) => setForm((p) => ({ ...p, department: v }))} testId="admin-create-department" />
            <Field label="Username" id="username" value={form.username} onChange={(v) => setForm((p) => ({ ...p, username: v }))} testId="admin-create-username" />
            <Field label="Profile Image URL" id="profile_image_url" value={form.profile_image_url} onChange={(v) => setForm((p) => ({ ...p, profile_image_url: v }))} testId="admin-create-profile-image" />
            <Field label="Personal Email" id="personal_email" value={form.personal_email} onChange={(v) => setForm((p) => ({ ...p, personal_email: v }))} testId="admin-create-personal-email" />
            <Field label="College Email" id="college_email" value={form.college_email} onChange={(v) => setForm((p) => ({ ...p, college_email: v }))} testId="admin-create-college-email" />
            <Field label="Current Role" id="current_role" value={form.current_role} onChange={(v) => setForm((p) => ({ ...p, current_role: v }))} testId="admin-create-current-role" />
            <Field label="Current Company" id="current_company" value={form.current_company} onChange={(v) => setForm((p) => ({ ...p, current_company: v }))} testId="admin-create-current-company" />
          </div>

          {!minimalProfileMode && (
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Batch" id="batch" value={form.batch} onChange={(v) => setForm((p) => ({ ...p, batch: v }))} testId="admin-create-batch" />
              <Field label="Course" id="course" value={form.course} onChange={(v) => setForm((p) => ({ ...p, course: v }))} testId="admin-create-course" />
              <Field label="Degree" id="degree_level" value={form.degree_level} onChange={(v) => setForm((p) => ({ ...p, degree_level: v }))} testId="admin-create-degree" />
              <Field label="Passed Out" id="passed_out" value={form.passed_out} onChange={(v) => setForm((p) => ({ ...p, passed_out: v }))} testId="admin-create-passed-out" />
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Interests (comma separated)" id="interests" value={form.interests} onChange={(v) => setForm((p) => ({ ...p, interests: v }))} testId="admin-create-interests" />
            <Field label="Mentorship Categories" id="mentorship_categories" value={form.mentorship_categories} onChange={(v) => setForm((p) => ({ ...p, mentorship_categories: v }))} testId="admin-create-mentorship-categories" />
            {!minimalProfileMode && (
              <>
                <Field label="Internships (comma separated)" id="internship_done" value={form.internship_done} onChange={(v) => setForm((p) => ({ ...p, internship_done: v }))} testId="admin-create-internships" />
                <Field label="Companies Worked In" id="companies_worked_in" value={form.companies_worked_in} onChange={(v) => setForm((p) => ({ ...p, companies_worked_in: v }))} testId="admin-create-companies" />
                <Field label="Committees" id="committees" value={form.committees} onChange={(v) => setForm((p) => ({ ...p, committees: v }))} testId="admin-create-committees" />
                <Field label="Groups" id="groups" value={form.groups} onChange={(v) => setForm((p) => ({ ...p, groups: v }))} testId="admin-create-groups" />
              </>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio" data-testid="admin-create-bio-label">Bio</Label>
            <Textarea id="bio" data-testid="admin-create-bio-input" value={form.bio} onChange={(event) => setForm((p) => ({ ...p, bio: event.target.value }))} />
          </div>

          <div className="flex flex-wrap gap-5">
            <label className="flex items-center gap-2 text-sm" data-testid="admin-create-currently-pursuing-toggle">
              <input type="checkbox" checked={form.currently_pursuing} onChange={(event) => setForm((p) => ({ ...p, currently_pursuing: event.target.checked }))} data-testid="admin-create-currently-pursuing-checkbox" />
              Currently pursuing
            </label>
            <label className="flex items-center gap-2 text-sm" data-testid="admin-create-placed-from-college-toggle">
              <input type="checkbox" checked={form.placed_from_college} onChange={(event) => setForm((p) => ({ ...p, placed_from_college: event.target.checked }))} data-testid="admin-create-placed-from-college-checkbox" />
              Placed from college
            </label>
            <label className="flex items-center gap-2 text-sm" data-testid="admin-create-mentorship-available-toggle">
              <input type="checkbox" checked={form.mentorship_available} onChange={(event) => setForm((p) => ({ ...p, mentorship_available: event.target.checked }))} data-testid="admin-create-mentorship-available-checkbox" />
              Mentorship available
            </label>
          </div>

          <div>
            <p className="text-sm font-medium mb-2" data-testid="admin-create-roles-label">Assign Roles</p>
            <div className="flex flex-wrap gap-2" data-testid="admin-create-role-options">
              {roles.map((role) => (
                <button
                  key={role}
                  type="button"
                  onClick={() => toggleRole(role)}
                  className={[
                    "rounded-full px-4 py-2 text-sm border transition-colors",
                    form.roles.includes(role)
                      ? "border-[#1e3a8a] bg-[#dbeafe] text-[#1e3a8a]"
                      : "border-slate-200 bg-slate-50 text-slate-700",
                  ].join(" ")}
                  data-testid={`admin-create-role-toggle-${role}`}
                >
                  {role}
                </button>
              ))}
            </div>
          </div>

          <Button type="submit" disabled={creating} data-testid="admin-create-user-submit-button">
            {creating ? "Creating..." : "Create Account"}
          </Button>
        </form>

        <section className="rounded-2xl border border-slate-200 bg-white p-5" data-testid="admin-users-list-section">
          <div className="flex items-center justify-between gap-3 mb-4">
            <h2 className="text-lg font-semibold" data-testid="admin-users-list-title">All Accounts</h2>
            <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search users" className="max-w-[180px]" data-testid="admin-users-search-input" />
          </div>

          <div className="space-y-3 max-h-[850px] overflow-auto pr-1" data-testid="admin-users-list">
            {loading ? (
              <p className="text-sm text-slate-500" data-testid="admin-users-loading">Loading users...</p>
            ) : filteredUsers.length === 0 ? (
              <p className="text-sm text-slate-500" data-testid="admin-users-empty">No users found.</p>
            ) : (
              filteredUsers.map((user) => (
                <article key={user.user_id} className="rounded-xl border border-slate-200 p-4" data-testid={`admin-user-card-${user.user_id}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex gap-3">
                      <img
                        src={user.profile_image_url || "https://placehold.co/80x80?text=User"}
                        alt={user.name}
                        className="h-14 w-14 rounded-full object-cover border border-slate-200"
                        data-testid={`admin-user-image-${user.user_id}`}
                      />
                      <div>
                        <h3 className="font-semibold" data-testid={`admin-user-name-${user.user_id}`}>{user.name}</h3>
                        <p className="text-xs text-slate-500" data-testid={`admin-user-username-${user.user_id}`}>@{user.username}</p>
                        <p className="text-xs text-slate-500 mt-1" data-testid={`admin-user-course-${user.user_id}`}>
                          {user.roles?.includes("admin") || user.mentorship_available
                            ? "Minimal profile mode"
                            : `${user.course || "No course"} · Batch ${user.batch || "NA"}`}
                        </p>
                        <p className="text-xs text-slate-500 mt-1" data-testid={`admin-user-department-${user.user_id}`}>
                          Department: {user.department || "Not set"}
                        </p>
                        <p className="text-xs mt-1" data-testid={`admin-user-status-${user.user_id}`}>
                          Status: {user.is_active === false ? "Inactive" : "Active"}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1" data-testid={`admin-user-roles-${user.user_id}`}>
                      {user.roles?.map((role) => (
                        <Badge key={`${user.user_id}-${role}`} className="capitalize" data-testid={`admin-user-role-${user.user_id}-${role}`}>
                          {role}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button variant="outline" size="sm" onClick={() => startEditUser(user)} data-testid={`admin-user-edit-${user.user_id}`}>
                      Update
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => promoteToAlumni(user)} data-testid={`admin-user-toggle-alumni-${user.user_id}`}>
                      {user.roles?.includes("alumni") ? "Remove Alumni Role" : "Promote to Alumni"}
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => resetUserPassword(user.user_id)} data-testid={`admin-user-reset-password-${user.user_id}`}>
                      Reset Password
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleUserActive(user)}
                      data-testid={`admin-user-toggle-active-${user.user_id}`}
                    >
                      {user.is_active === false ? "Restore" : "Remove"}
                    </Button>
                  </div>
                </article>
              ))
            )}
          </div>
        </section>
      </div>
    </section>
  );
}

const Field = ({ id, label, value, onChange, testId }) => (
  <div className="space-y-2">
    <Label htmlFor={id} data-testid={`${testId}-label`}>{label}</Label>
    <Input id={id} value={value || ""} onChange={(event) => onChange(event.target.value)} data-testid={`${testId}-input`} />
  </div>
);
