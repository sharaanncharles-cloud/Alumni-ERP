import { useState } from "react";
import { Link } from "react-router-dom";
import { api, getApiError } from "@/api";
import { toast } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function ForgotPasswordPage() {
  const [identifier, setIdentifier] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [previewLink, setPreviewLink] = useState("");

  const onSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);
    try {
      const response = await api.post("/auth/forgot-password", { identifier });
      toast.success(response.data.message || "Reset instructions sent");
      setPreviewLink(response.data.reset_link_preview || "");
    } catch (error) {
      toast.error(getApiError(error, "Unable to send reset instructions"));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-[#eff6ff] to-[#fdf2f8]" data-testid="forgot-password-page">
      <div className="w-full max-w-md rounded-2xl border border-slate-200/80 bg-white p-6 shadow-lg" data-testid="forgot-password-card">
        <h1 className="text-2xl font-heading text-[#1e3a8a] mb-2" data-testid="forgot-password-title">
          Reset your password
        </h1>
        <p className="text-sm text-slate-600 mb-5" data-testid="forgot-password-description">
          Enter your username or registered email to receive a reset link.
        </p>

        <form onSubmit={onSubmit} className="space-y-4" data-testid="forgot-password-form">
          <div className="space-y-2">
            <Label htmlFor="identifier" data-testid="forgot-password-identifier-label">
              Username or email
            </Label>
            <Input
              id="identifier"
              data-testid="forgot-password-identifier-input"
              value={identifier}
              onChange={(event) => setIdentifier(event.target.value)}
              placeholder="admin or user@college.edu"
              required
            />
          </div>

          <Button type="submit" className="w-full" disabled={submitting} data-testid="forgot-password-submit-button">
            {submitting ? "Sending..." : "Send Reset Link"}
          </Button>
        </form>

        {previewLink && (
          <div className="mt-4 rounded-xl bg-amber-50 border border-amber-200 p-3" data-testid="forgot-password-preview-link-container">
            <p className="text-xs text-amber-700 mb-2" data-testid="forgot-password-preview-note">
              Email service is not configured yet. Use preview link:
            </p>
            <a href={previewLink} className="text-xs break-all underline text-[#1e3a8a]" data-testid="forgot-password-preview-link">
              {previewLink}
            </a>
          </div>
        )}

        <div className="mt-5 text-center" data-testid="forgot-password-back-login-wrapper">
          <Link to="/login" className="text-sm text-slate-600 underline" data-testid="forgot-password-back-login-link">
            Back to login
          </Link>
        </div>
      </div>
    </div>
  );
}
