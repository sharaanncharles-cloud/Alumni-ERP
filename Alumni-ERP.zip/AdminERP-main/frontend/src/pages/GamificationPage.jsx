import { useCallback, useEffect, useMemo, useState } from "react";
import { api, getApiError } from "@/api";
import { toast } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

const MEMORY_SYMBOLS = ["🎓", "🚀", "💼", "🤝"];

const createMemoryDeck = () => {
  const doubled = [...MEMORY_SYMBOLS, ...MEMORY_SYMBOLS];
  const cards = doubled.map((symbol, index) => ({ id: `card-${index}-${Math.random()}`, symbol }));
  return cards.sort(() => Math.random() - 0.5);
};

const calculateMemoryScore = (moves, seconds) => {
  const base = 120;
  const penalty = moves * 4 + seconds * 2;
  return Math.max(base - penalty, 10);
};

export default function GamificationPage() {
  const [dashboard, setDashboard] = useState(null);
  const [profiles, setProfiles] = useState([]);
  const [applaudForm, setApplaudForm] = useState({ to_user_id: "", reason: "" });
  const [referralForm, setReferralForm] = useState({ student_id: "", company: "", job_title: "", status: "pending" });

  const [tapGameActive, setTapGameActive] = useState(false);
  const [tapTimeLeft, setTapTimeLeft] = useState(10);
  const [tapScore, setTapScore] = useState(0);
  const [tapBestScore, setTapBestScore] = useState(0);

  const [memoryCards, setMemoryCards] = useState([]);
  const [memoryFlipped, setMemoryFlipped] = useState([]);
  const [memoryMatchedIds, setMemoryMatchedIds] = useState([]);
  const [memoryMoves, setMemoryMoves] = useState(0);
  const [memorySeconds, setMemorySeconds] = useState(0);
  const [memoryRunning, setMemoryRunning] = useState(false);
  const [memoryLocked, setMemoryLocked] = useState(false);
  const [memoryBestScore, setMemoryBestScore] = useState(0);
  const [memoryLastScore, setMemoryLastScore] = useState(0);

  const loadData = useCallback(async () => {
    try {
      const [dashboardResponse, profileResponse] = await Promise.all([
        api.get("/gamification/dashboard"),
        api.get("/profiles"),
      ]);
      const dashboardData = dashboardResponse.data;
      const allProfiles = profileResponse.data.profiles || [];
      setDashboard(dashboardData);
      setProfiles(allProfiles);

      setTapBestScore(dashboardData?.mini_games?.user_best_scores?.tap_speed || 0);
      setMemoryBestScore(dashboardData?.mini_games?.user_best_scores?.memory_flip || 0);

      if (allProfiles[0]) {
        setApplaudForm((prev) => ({ ...prev, to_user_id: prev.to_user_id || allProfiles[0].user_id }));
      }
      const firstStudent = allProfiles.find((item) => item.roles?.includes("student"));
      if (firstStudent) {
        setReferralForm((prev) => ({ ...prev, student_id: prev.student_id || firstStudent.user_id }));
      }
    } catch (error) {
      toast.error(getApiError(error, "Could not load gamification"));
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const saveMiniGameScore = useCallback(
    async (gameType, score) => {
      try {
        const response = await api.post("/gamification/mini-games/score", {
          game_type: gameType,
          score,
        });
        if (gameType === "tap_speed") {
          setTapBestScore(response.data.best_score || 0);
        }
        if (gameType === "memory_flip") {
          setMemoryBestScore(response.data.best_score || 0);
        }
        if (response.data.is_new_best) {
          toast.success(`New ${gameType.replace("_", " ")} best score: ${response.data.best_score}`);
        }
        await loadData();
      } catch (error) {
        toast.error(getApiError(error, "Could not save game score"));
      }
    },
    [loadData],
  );

  useEffect(() => {
    if (!tapGameActive) return;
    if (tapTimeLeft <= 0) {
      setTapGameActive(false);
      setTapBestScore((prev) => Math.max(prev, tapScore));
      saveMiniGameScore("tap_speed", tapScore);
      return;
    }

    const intervalId = setInterval(() => {
      setTapTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(intervalId);
  }, [tapGameActive, tapTimeLeft, tapScore, saveMiniGameScore]);

  useEffect(() => {
    if (!memoryRunning) return;
    const timerId = setInterval(() => {
      setMemorySeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timerId);
  }, [memoryRunning]);

  useEffect(() => {
    if (!memoryRunning || memoryCards.length === 0) return;
    if (memoryMatchedIds.length !== memoryCards.length) return;

    setMemoryRunning(false);
    const finalScore = calculateMemoryScore(memoryMoves, memorySeconds);
    setMemoryLastScore(finalScore);
    setMemoryBestScore((prev) => Math.max(prev, finalScore));
    saveMiniGameScore("memory_flip", finalScore);
  }, [
    memoryCards.length,
    memoryMatchedIds.length,
    memoryMoves,
    memoryRunning,
    memorySeconds,
    saveMiniGameScore,
  ]);

  const students = useMemo(() => profiles.filter((item) => item.roles?.includes("student")), [profiles]);

  const completeChallenge = async (challengeId) => {
    try {
      const response = await api.post(`/gamification/challenges/${challengeId}/complete`);
      toast.success(response.data.message || "Challenge completed");
      await loadData();
    } catch (error) {
      toast.error(getApiError(error, "Could not complete challenge"));
    }
  };

  const applaud = async () => {
    try {
      const response = await api.post("/gamification/applaud", applaudForm);
      toast.success(response.data.message || "Applaud sent");
      setApplaudForm((prev) => ({ ...prev, reason: "" }));
      await loadData();
    } catch (error) {
      toast.error(getApiError(error, "Could not send applaud"));
    }
  };

  const createReferral = async () => {
    try {
      const response = await api.post("/gamification/referrals", referralForm);
      toast.success(response.data.message || "Referral created");
      setReferralForm((prev) => ({ ...prev, company: "", job_title: "" }));
      await loadData();
    } catch (error) {
      toast.error(getApiError(error, "Could not create referral"));
    }
  };

  const startTapGame = () => {
    setTapScore(0);
    setTapTimeLeft(10);
    setTapGameActive(true);
  };

  const tapMiniGame = () => {
    if (!tapGameActive || tapTimeLeft <= 0) return;
    setTapScore((prev) => prev + 1);
  };

  const startMemoryGame = () => {
    setMemoryCards(createMemoryDeck());
    setMemoryFlipped([]);
    setMemoryMatchedIds([]);
    setMemoryMoves(0);
    setMemorySeconds(0);
    setMemoryLocked(false);
    setMemoryRunning(true);
    setMemoryLastScore(0);
  };

  const flipMemoryCard = (card) => {
    if (!memoryRunning || memoryLocked) return;
    if (memoryMatchedIds.includes(card.id)) return;
    if (memoryFlipped.find((item) => item.id === card.id)) return;

    const nextFlipped = [...memoryFlipped, card];
    setMemoryFlipped(nextFlipped);

    if (nextFlipped.length < 2) return;

    setMemoryMoves((prev) => prev + 1);
    setMemoryLocked(true);

    const [first, second] = nextFlipped;
    if (first.symbol === second.symbol) {
      setTimeout(() => {
        setMemoryMatchedIds((prev) => [...prev, first.id, second.id]);
        setMemoryFlipped([]);
        setMemoryLocked(false);
      }, 300);
      return;
    }

    setTimeout(() => {
      setMemoryFlipped([]);
      setMemoryLocked(false);
    }, 700);
  };

  const isMemoryCardVisible = (card) => {
    return memoryMatchedIds.includes(card.id) || memoryFlipped.some((item) => item.id === card.id);
  };

  const tapLeaderboard = dashboard?.mini_games?.tap_speed_leaderboard || [];
  const memoryLeaderboard = dashboard?.mini_games?.memory_flip_leaderboard || [];

  return (
    <section data-testid="gamification-page">
      <h1 className="font-heading text-4xl sm:text-5xl text-[#1e3a8a]" data-testid="gamification-title">
        Gamification Center
      </h1>
      <p className="text-base text-slate-600 mt-3 mb-8" data-testid="gamification-description">
        Earn points with challenges, applauds, referrals, and mini games.
      </p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4" data-testid="gamification-metrics-grid">
        <MetricCard label="Points" value={dashboard?.user_stats?.points || 0} testId="gamification-points-card" />
        <MetricCard label="Streak" value={dashboard?.user_stats?.streak || 0} testId="gamification-streak-card" />
        <MetricCard label="Applauds" value={dashboard?.user_stats?.applauds_received || 0} testId="gamification-applauds-card" />
        <MetricCard label="Referral Points" value={dashboard?.user_stats?.referral_points || 0} testId="gamification-referral-card" />
      </div>

      <div className="mt-6 rounded-2xl border border-[#f3cff8] bg-gradient-to-br from-white to-[#fff3fb] p-5" data-testid="gamification-badges-section">
        <h2 className="text-lg font-semibold mb-3" data-testid="gamification-badges-title">Badges</h2>
        <div className="flex flex-wrap gap-2" data-testid="gamification-badges-list">
          {(dashboard?.user_stats?.badges || []).length === 0 ? (
            <p className="text-sm text-slate-500" data-testid="gamification-no-badges">No badges yet. Keep engaging!</p>
          ) : (
            dashboard.user_stats.badges.map((badge) => (
              <Badge key={badge} className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white" data-testid={`gamification-badge-${badge.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}>
                {badge}
              </Badge>
            ))
          )}
        </div>
      </div>

      <div className="grid xl:grid-cols-2 gap-6 mt-6">
        <section className="rounded-2xl border border-[#f3cff8] bg-gradient-to-br from-white to-[#fff3fb] p-5" data-testid="gamification-challenges-card">
          <h2 className="text-lg font-semibold mb-4" data-testid="gamification-challenges-title">Daily Challenges</h2>
          <div className="space-y-3" data-testid="gamification-challenges-list">
            {(dashboard?.daily_challenges || []).map((challenge) => (
              <div key={challenge.id} className="rounded-xl border border-slate-200 p-3 flex flex-wrap items-center justify-between gap-3" data-testid={`gamification-challenge-${challenge.id}`}>
                <div>
                  <p className="font-medium" data-testid={`gamification-challenge-title-${challenge.id}`}>{challenge.title}</p>
                  <p className="text-xs text-slate-500" data-testid={`gamification-challenge-points-${challenge.id}`}>{challenge.points} points</p>
                </div>
                <Button disabled={challenge.completed} onClick={() => completeChallenge(challenge.id)} data-testid={`gamification-complete-challenge-${challenge.id}`}>
                  {challenge.completed ? "Completed" : "Complete"}
                </Button>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-[#f3cff8] bg-gradient-to-br from-white to-[#fff3fb] p-5" data-testid="gamification-actions-card">
          <h2 className="text-lg font-semibold mb-4" data-testid="gamification-actions-title">Applauds & Referrals</h2>

          <div className="space-y-3" data-testid="gamification-applaud-form">
            <label className="text-sm font-medium" data-testid="gamification-applaud-user-label">Applaud User</label>
            <select className="w-full border border-slate-200 rounded-lg p-2" value={applaudForm.to_user_id} onChange={(event) => setApplaudForm((prev) => ({ ...prev, to_user_id: event.target.value }))} data-testid="gamification-applaud-user-select">
              {profiles.map((profile) => (
                <option key={profile.user_id} value={profile.user_id} data-testid={`gamification-applaud-option-${profile.user_id}`}>
                  {profile.name}
                </option>
              ))}
            </select>
            <Input value={applaudForm.reason} onChange={(event) => setApplaudForm((prev) => ({ ...prev, reason: event.target.value }))} placeholder="Reason for applaud" data-testid="gamification-applaud-reason-input" />
            <Button variant="outline" onClick={applaud} data-testid="gamification-applaud-submit-button">Send Applaud</Button>
          </div>

          <div className="space-y-3 mt-6" data-testid="gamification-referral-form">
            <label className="text-sm font-medium" data-testid="gamification-referral-student-label">Refer a Student</label>
            <select className="w-full border border-slate-200 rounded-lg p-2" value={referralForm.student_id} onChange={(event) => setReferralForm((prev) => ({ ...prev, student_id: event.target.value }))} data-testid="gamification-referral-student-select">
              {students.map((student) => (
                <option key={student.user_id} value={student.user_id} data-testid={`gamification-referral-option-${student.user_id}`}>
                  {student.name}
                </option>
              ))}
            </select>
            <Input value={referralForm.company} onChange={(event) => setReferralForm((prev) => ({ ...prev, company: event.target.value }))} placeholder="Company" data-testid="gamification-referral-company-input" />
            <Input value={referralForm.job_title} onChange={(event) => setReferralForm((prev) => ({ ...prev, job_title: event.target.value }))} placeholder="Job title" data-testid="gamification-referral-job-title-input" />
            <select className="w-full border border-slate-200 rounded-lg p-2" value={referralForm.status} onChange={(event) => setReferralForm((prev) => ({ ...prev, status: event.target.value }))} data-testid="gamification-referral-status-select">
              <option value="pending">Pending</option>
              <option value="successful">Successful</option>
              <option value="rejected">Rejected</option>
            </select>
            <Button variant="outline" onClick={createReferral} data-testid="gamification-referral-submit-button">Create Referral</Button>
          </div>
        </section>
      </div>

      <section className="rounded-2xl border border-[#f3cff8] bg-gradient-to-br from-white to-[#fff3fb] p-5 mt-6" data-testid="gamification-leaderboard-card">
        <h2 className="text-lg font-semibold mb-4" data-testid="gamification-leaderboard-title">Engagement Leaderboard</h2>
        <div className="space-y-2" data-testid="gamification-leaderboard-list">
          {(dashboard?.leaderboard || []).map((entry, index) => (
            <div key={`${entry.username}-${index}`} className="rounded-xl border border-slate-200 px-4 py-3 flex items-center justify-between" data-testid={`gamification-leaderboard-row-${index + 1}`}>
              <p className="text-sm font-medium" data-testid={`gamification-leaderboard-name-${index + 1}`}>
                #{index + 1} {entry.name || entry.username}
              </p>
              <p className="text-sm text-[#1e3a8a] font-semibold" data-testid={`gamification-leaderboard-points-${index + 1}`}>
                {entry.gamification_points || entry.points || 0} pts
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-[#ffd6a5] bg-gradient-to-br from-[#fff5e8] to-[#ffe0c2] p-5 mt-6" data-testid="gamification-mini-games-wrapper">
        <h2 className="text-lg font-semibold mb-2" data-testid="gamification-mini-games-title">Mini Games</h2>
        <p className="text-sm text-slate-700" data-testid="gamification-mini-games-description">
          Play Tap Speed and Memory Flip. Scores are saved to your profile and leaderboard.
        </p>

        <div className="grid lg:grid-cols-2 gap-6 mt-5" data-testid="gamification-mini-games-grid">
          <article className="rounded-xl border border-[#f2b47a] bg-white/70 p-4" data-testid="gamification-tap-game-card">
            <h3 className="font-semibold" data-testid="gamification-tap-title">Tap Speed (10s)</h3>
            <p className="text-xs text-slate-600 mt-1" data-testid="gamification-tap-description">Tap as many times as possible in 10 seconds.</p>

            <div className="mt-3 flex flex-wrap items-center gap-2" data-testid="gamification-tap-stats">
              <Badge className="bg-[#7c2d12] text-white" data-testid="gamification-tap-time">Time: {tapTimeLeft}s</Badge>
              <Badge className="bg-[#0f766e] text-white" data-testid="gamification-tap-live-score">Score: {tapScore}</Badge>
              <Badge variant="secondary" data-testid="gamification-tap-best-score">Best: {tapBestScore}</Badge>
            </div>

            <div className="mt-4 flex flex-wrap gap-3" data-testid="gamification-tap-controls">
              <Button onClick={startTapGame} data-testid="gamification-tap-start-button">
                {tapGameActive ? "Restart" : "Start"}
              </Button>
              <button
                type="button"
                onClick={tapMiniGame}
                disabled={!tapGameActive || tapTimeLeft <= 0}
                className="w-28 h-28 rounded-full border-4 border-[#7c2d12] bg-[#ffb869] text-[#52200f] font-semibold text-lg shadow-lg transition-transform active:scale-95 disabled:opacity-50"
                data-testid="gamification-tap-button"
              >
                TAP
              </button>
            </div>

            <div className="mt-4" data-testid="gamification-tap-leaderboard">
              <p className="text-sm font-medium mb-2" data-testid="gamification-tap-leaderboard-title">Tap Speed Top Scores</p>
              <div className="space-y-1" data-testid="gamification-tap-leaderboard-list">
                {tapLeaderboard.length === 0 ? (
                  <p className="text-xs text-slate-500" data-testid="gamification-tap-leaderboard-empty">No scores yet.</p>
                ) : (
                  tapLeaderboard.slice(0, 5).map((entry, index) => (
                    <div key={`${entry.username}-${index}`} className="text-xs flex justify-between" data-testid={`gamification-tap-leader-row-${index + 1}`}>
                      <span data-testid={`gamification-tap-leader-name-${index + 1}`}>#{index + 1} {entry.name}</span>
                      <span data-testid={`gamification-tap-leader-score-${index + 1}`}>{entry.best_score}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </article>

          <article className="rounded-xl border border-[#f2b47a] bg-white/70 p-4" data-testid="gamification-memory-game-card">
            <h3 className="font-semibold" data-testid="gamification-memory-title">Memory Flip</h3>
            <p className="text-xs text-slate-600 mt-1" data-testid="gamification-memory-description">
              Match all pairs quickly with fewer moves for a higher score.
            </p>

            <div className="mt-3 flex flex-wrap items-center gap-2" data-testid="gamification-memory-stats">
              <Badge className="bg-[#7c2d12] text-white" data-testid="gamification-memory-seconds">Time: {memorySeconds}s</Badge>
              <Badge className="bg-[#0f766e] text-white" data-testid="gamification-memory-moves">Moves: {memoryMoves}</Badge>
              <Badge variant="secondary" data-testid="gamification-memory-best-score">Best: {memoryBestScore}</Badge>
              <Badge variant="secondary" data-testid="gamification-memory-last-score">Last: {memoryLastScore}</Badge>
            </div>

            <div className="mt-3 flex gap-2" data-testid="gamification-memory-controls">
              <Button onClick={startMemoryGame} data-testid="gamification-memory-start-button">
                {memoryRunning ? "Restart" : "Start"}
              </Button>
            </div>

            <div className="mt-4 grid grid-cols-4 gap-2" data-testid="gamification-memory-grid">
              {memoryCards.length === 0 ? (
                <p className="text-xs text-slate-500 col-span-4" data-testid="gamification-memory-empty">
                  Click Start to begin Memory Flip.
                </p>
              ) : (
                memoryCards.map((card, index) => (
                  <button
                    key={card.id}
                    type="button"
                    onClick={() => flipMemoryCard(card)}
                    disabled={!memoryRunning || memoryLocked}
                    className="aspect-square rounded-lg border border-slate-300 bg-white text-xl font-semibold"
                    data-testid={`gamification-memory-card-${index + 1}`}
                  >
                    {isMemoryCardVisible(card) ? card.symbol : "?"}
                  </button>
                ))
              )}
            </div>

            <div className="mt-4" data-testid="gamification-memory-leaderboard">
              <p className="text-sm font-medium mb-2" data-testid="gamification-memory-leaderboard-title">Memory Flip Top Scores</p>
              <div className="space-y-1" data-testid="gamification-memory-leaderboard-list">
                {memoryLeaderboard.length === 0 ? (
                  <p className="text-xs text-slate-500" data-testid="gamification-memory-leaderboard-empty">No scores yet.</p>
                ) : (
                  memoryLeaderboard.slice(0, 5).map((entry, index) => (
                    <div key={`${entry.username}-${index}`} className="text-xs flex justify-between" data-testid={`gamification-memory-leader-row-${index + 1}`}>
                      <span data-testid={`gamification-memory-leader-name-${index + 1}`}>#{index + 1} {entry.name}</span>
                      <span data-testid={`gamification-memory-leader-score-${index + 1}`}>{entry.best_score}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </article>
        </div>
      </section>
    </section>
  );
}

const MetricCard = ({ label, value, testId }) => (
  <article className="rounded-2xl border border-[#f3cff8] bg-gradient-to-br from-white to-[#fff3fb] p-4" data-testid={testId}>
    <p className="text-sm text-slate-500" data-testid={`${testId}-label`}>{label}</p>
    <p className="text-2xl font-semibold text-[#1e3a8a]" data-testid={`${testId}-value`}>{value}</p>
  </article>
);
