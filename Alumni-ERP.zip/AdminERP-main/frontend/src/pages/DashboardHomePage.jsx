import { useEffect, useState } from "react";
import { api, getApiError } from "@/api";
import { toast } from "@/components/ui/sonner";
import { useAuth } from "@/context/AuthContext";
import { Badge } from "@/components/ui/badge";

export default function DashboardHomePage() {
  const { user, hasRole } = useAuth();
  const [summary, setSummary] = useState(null);
  const [announcements, setAnnouncements] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        const announcementPromise = api.get("/announcements");
        const [announcementResponse, summaryResponse] = await Promise.all([
          announcementPromise,
          hasRole("admin") ? api.get("/admin/analytics") : api.get("/gamification/dashboard"),
        ]);
        setAnnouncements(announcementResponse.data.announcements || []);
        setSummary(summaryResponse.data);
      } catch (error) {
        toast.error(getApiError(error, "Could not load dashboard"));
      }
    };

    loadData();
  }, [hasRole]);

  return (
    <section data-testid="dashboard-home-page">
      <h1 className="font-heading text-4xl sm:text-5xl text-[#1e3a8a]" data-testid="dashboard-home-title">
        Dashboard Overview
      </h1>
      <p className="text-base text-slate-600 mt-3" data-testid="dashboard-home-description">
        Track your alumni community activity, placements, and engagement in one place.
      </p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-8" data-testid="dashboard-metrics-grid">
        {hasRole("admin") ? (
          <>
            <MetricCard label="Total Users" value={summary?.totals?.users ?? "-"} testId="metric-total-users" />
            <MetricCard label="Students" value={summary?.totals?.students ?? "-"} testId="metric-total-students" />
            <MetricCard label="Alumni" value={summary?.totals?.alumni ?? "-"} testId="metric-total-alumni" />
            <MetricCard label="Referrals" value={summary?.totals?.referrals ?? "-"} testId="metric-total-referrals" />
          </>
        ) : (
          <>
            <MetricCard label="Points" value={summary?.user_stats?.points ?? 0} testId="metric-user-points" />
            <MetricCard label="Streak" value={summary?.user_stats?.streak ?? 0} testId="metric-user-streak" />
            <MetricCard
              label="Applauds"
              value={summary?.user_stats?.applauds_received ?? 0}
              testId="metric-user-applauds"
            />
            <MetricCard
              label="Referral Points"
              value={summary?.user_stats?.referral_points ?? 0}
              testId="metric-user-referral-points"
            />
          </>
        )}
      </div>

      <div className="grid lg:grid-cols-2 gap-6 mt-8">
        <section className="rounded-2xl border border-slate-200 bg-white p-5" data-testid="dashboard-role-card">
          <h2 className="text-lg font-semibold mb-3" data-testid="dashboard-role-card-title">Your Roles</h2>
          <div className="flex flex-wrap gap-2" data-testid="dashboard-role-badges">
            {user?.roles?.map((role) => (
              <Badge key={role} className="capitalize" data-testid={`dashboard-role-${role}`}>
                {role}
              </Badge>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-5" data-testid="dashboard-announcements-card">
          <h2 className="text-lg font-semibold mb-3" data-testid="dashboard-announcements-title">Recent Announcements</h2>
          <div className="space-y-3 max-h-72 overflow-auto" data-testid="dashboard-announcements-list">
            {announcements.length === 0 ? (
              <p className="text-sm text-slate-500" data-testid="dashboard-no-announcements">No announcements yet.</p>
            ) : (
              announcements.slice(0, 5).map((item) => (
                <div key={item.announcement_id} className="rounded-xl border border-slate-200 p-3" data-testid={`dashboard-announcement-${item.announcement_id}`}>
                  <p className="font-medium" data-testid={`dashboard-announcement-title-${item.announcement_id}`}>{item.title}</p>
                  <p className="text-sm text-slate-600 mt-1" data-testid={`dashboard-announcement-message-${item.announcement_id}`}>{item.message}</p>
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </section>
  );
}

const MetricCard = ({ label, value, testId }) => (
  <article className="rounded-2xl border border-[#f0d4ff] bg-gradient-to-br from-white to-[#fff3ff] p-4 shadow-sm" data-testid={testId}>
    <p className="text-sm text-slate-500" data-testid={`${testId}-label`}>{label}</p>
    <p className="text-2xl font-semibold text-[#1e3a8a] mt-1" data-testid={`${testId}-value`}>{value}</p>
  </article>
);
