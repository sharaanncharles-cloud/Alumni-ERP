import { useEffect, useState } from "react";
import { api, getApiError } from "@/api";
import { toast } from "@/components/ui/sonner";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export default function DirectoryPage() {
  const [profiles, setProfiles] = useState([]);
  const [query, setQuery] = useState("");

  const loadProfiles = async (search = "") => {
    try {
      const response = await api.get("/profiles", {
        params: {
          role: "alumni",
          search,
        },
      });
      setProfiles(response.data.profiles || []);
    } catch (error) {
      toast.error(getApiError(error, "Could not load alumni directory"));
    }
  };

  useEffect(() => {
    loadProfiles("");
  }, []);

  return (
    <section data-testid="directory-page">
      <h1 className="font-heading text-4xl sm:text-5xl text-[#1e3a8a]" data-testid="directory-title">
        Alumni Directory
      </h1>
      <p className="text-base text-slate-600 mt-3 mb-6" data-testid="directory-description">
        Discover mentors, career paths, and alumni willing to help with referrals and guidance.
      </p>

      <div className="mb-5 flex flex-wrap gap-3" data-testid="directory-search-wrapper">
        <Input
          className="max-w-sm"
          placeholder="Search by name, company, course"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          data-testid="directory-search-input"
        />
        <button
          type="button"
          onClick={() => loadProfiles(query)}
          className="rounded-lg px-4 py-2 bg-[#1e3a8a] text-white text-sm"
          data-testid="directory-search-button"
        >
          Search
        </button>
      </div>

      <div className="grid md:grid-cols-2 gap-5" data-testid="directory-cards-grid">
        {profiles.length === 0 ? (
          <p className="text-sm text-slate-500" data-testid="directory-empty-state">No alumni profiles found.</p>
        ) : (
          profiles.map((profile) => (
            <article key={profile.user_id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm" data-testid={`directory-card-${profile.user_id}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex gap-3">
                  <img
                    src={profile.profile_image_url || "https://placehold.co/96x96?text=User"}
                    alt={profile.name}
                    className="h-16 w-16 rounded-full object-cover border border-slate-200"
                    data-testid={`directory-image-${profile.user_id}`}
                  />
                  <div>
                  <h2 className="text-lg font-semibold" data-testid={`directory-name-${profile.user_id}`}>{profile.name}</h2>
                  <p className="text-sm text-slate-600" data-testid={`directory-role-company-${profile.user_id}`}>
                    {profile.current_role || "Role not specified"} · {profile.current_company || "Company not specified"}
                  </p>
                  <p className="text-xs text-slate-500 mt-1" data-testid={`directory-department-${profile.user_id}`}>
                    Department: {profile.department || "Not specified"}
                  </p>
                  </div>
                </div>
                <Badge className="capitalize" data-testid={`directory-batch-${profile.user_id}`}>
                  Batch {profile.batch || "NA"}
                </Badge>
              </div>

              <p className="text-sm text-slate-700 mt-3 leading-relaxed" data-testid={`directory-bio-${profile.user_id}`}>
                {profile.bio || "No bio available."}
              </p>

              <div className="mt-4 flex flex-wrap gap-2" data-testid={`directory-mentorship-categories-${profile.user_id}`}>
                {(profile.mentorship_categories || []).map((category) => (
                  <Badge key={`${profile.user_id}-${category}`} variant="secondary" data-testid={`directory-mentorship-category-${profile.user_id}-${category.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}>
                    {category}
                  </Badge>
                ))}
              </div>
            </article>
          ))
        )}
      </div>
    </section>
  );
}
