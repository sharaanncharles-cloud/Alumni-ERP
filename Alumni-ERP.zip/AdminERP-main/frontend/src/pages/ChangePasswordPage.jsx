import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, getApiError } from "@/api";
import { toast } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";

export default function ChangePasswordPage() {
  const navigate = useNavigate();
  const { user, refreshProfile } = useAuth();
  const [form, setForm] = useState({ currentPassword: "", newPassword: "" });
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);
    try {
      const response = await api.post("/auth/change-password", {
        current_password: form.currentPassword,
        new_password: form.newPassword,
      });
      toast.success(response.data.message || "Password changed successfully");
      await refreshProfile();
      navigate("/app");
    } catch (error) {
      toast.error(getApiError(error, "Failed to change password"));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="max-w-2xl" data-testid="change-password-page">
      <h1 className="font-heading text-4xl sm:text-5xl text-[#1e3a8a]" data-testid="change-password-title">
        {user?.must_change_password ? "Set your secure password" : "Change your password"}
      </h1>
      <p className="text-base text-slate-600 mt-3 mb-8" data-testid="change-password-description">
        {user?.must_change_password
          ? "For security, you must change your temporary password before using the dashboard."
          : "Update your password anytime from this page."}
      </p>

      <form onSubmit={onSubmit} className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm" data-testid="change-password-form">
        <div className="space-y-2">
          <Label htmlFor="current-password" data-testid="change-password-current-label">
            Current password
          </Label>
          <Input
            id="current-password"
            type="password"
            data-testid="change-password-current-input"
            value={form.currentPassword}
            onChange={(event) => setForm((prev) => ({ ...prev, currentPassword: event.target.value }))}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="new-password" data-testid="change-password-new-label">
            New password
          </Label>
          <Input
            id="new-password"
            type="password"
            data-testid="change-password-new-input"
            value={form.newPassword}
            onChange={(event) => setForm((prev) => ({ ...prev, newPassword: event.target.value }))}
            required
          />
        </div>

        <Button type="submit" disabled={submitting} data-testid="change-password-submit-button">
          {submitting ? "Updating..." : "Update Password"}
        </Button>
      </form>
    </section>
  );
}
