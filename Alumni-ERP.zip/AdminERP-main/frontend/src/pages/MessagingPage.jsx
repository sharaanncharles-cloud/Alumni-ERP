import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, getApiError } from "@/api";
import { toast } from "@/components/ui/sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/context/AuthContext";

export default function MessagingPage() {
  const { user, hasRole } = useAuth();
  const [users, setUsers] = useState([]);
  const [groups, setGroups] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [directMessages, setDirectMessages] = useState([]);
  const [directText, setDirectText] = useState("");
  const [groupName, setGroupName] = useState("");
  const [groupMembers, setGroupMembers] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [joinGroupId, setJoinGroupId] = useState("");
  const [groupText, setGroupText] = useState("");
  const [announcement, setAnnouncement] = useState({ title: "", message: "" });
  const directMessagesEndRef = useRef(null);
  const groupMessagesEndRef = useRef(null);

  const allUsers = useMemo(() => [user, ...users].filter(Boolean), [user, users]);
  const userMap = useMemo(
    () => Object.fromEntries(allUsers.map((item) => [item.user_id, item])),
    [allUsers],
  );

  const loadUsers = useCallback(async () => {
    try {
      const response = await api.get("/profiles");
      const availableUsers = (response.data.profiles || []).filter((item) => item.user_id !== user?.user_id);
      setUsers(availableUsers);
      if (!selectedUserId && availableUsers[0]) {
        setSelectedUserId(availableUsers[0].user_id);
      }
    } catch (error) {
      toast.error(getApiError(error, "Could not load users"));
    }
  }, [selectedUserId, user?.user_id]);

  const loadGroups = useCallback(async () => {
    try {
      const response = await api.get("/messages/groups");
      setGroups(response.data.groups || []);
      if (!selectedGroupId && response.data.groups?.[0]) {
        setSelectedGroupId(response.data.groups[0].group_id);
      }
    } catch (error) {
      toast.error(getApiError(error, "Could not load groups"));
    }
  }, [selectedGroupId]);

  const loadConversation = useCallback(async (targetUserId) => {
    if (!targetUserId) return;
    try {
      const response = await api.get(`/messages/direct/${targetUserId}`);
      setDirectMessages(response.data.messages || []);
    } catch (error) {
      toast.error(getApiError(error, "Could not load conversation"));
    }
  }, []);

  useEffect(() => {
    loadUsers();
    loadGroups();
  }, [loadGroups, loadUsers]);

  useEffect(() => {
    if (selectedUserId) {
      loadConversation(selectedUserId);
    }
  }, [loadConversation, selectedUserId]);

  const sendDirectMessage = async () => {
    if (!selectedUserId || !directText.trim()) return;
    try {
      await api.post("/messages/direct", {
        to_user_id: selectedUserId,
        content: directText,
      });
      setDirectText("");
      await loadConversation(selectedUserId);
      toast.success("Direct message sent");
    } catch (error) {
      toast.error(getApiError(error, "Could not send direct message"));
    }
  };

  const createGroup = async () => {
    try {
      const memberIds = groupMembers
        .split(",")
        .map((value) => value.trim())
        .filter(Boolean);
      const response = await api.post("/messages/groups", {
        name: groupName,
        member_ids: memberIds,
      });
      toast.success(response.data.message || "Group created");
      setGroupName("");
      setGroupMembers("");
      await loadGroups();
      if (response?.data?.group?.group_id) {
        setSelectedGroupId(response.data.group.group_id);
      }
    } catch (error) {
      toast.error(getApiError(error, "Could not create group"));
    }
  };

  const joinGroup = async () => {
    if (!joinGroupId.trim()) return;
    try {
      const response = await api.post(`/messages/groups/${joinGroupId.trim()}/join`);
      toast.success(response.data.message || "Joined group");
      setJoinGroupId("");
      await loadGroups();
    } catch (error) {
      toast.error(getApiError(error, "Could not join group"));
    }
  };

  const sendGroupMessage = async () => {
    if (!selectedGroupId || !groupText.trim()) return;
    try {
      await api.post(`/messages/groups/${selectedGroupId}/messages`, { content: groupText });
      setGroupText("");
      toast.success("Group message sent");
      await loadGroups();
    } catch (error) {
      toast.error(getApiError(error, "Could not send group message"));
    }
  };

  const postAnnouncement = async () => {
    try {
      const response = await api.post("/announcements", announcement);
      toast.success(response.data.message || "Announcement posted");
      setAnnouncement({ title: "", message: "" });
    } catch (error) {
      toast.error(getApiError(error, "Could not post announcement"));
    }
  };

  const selectedGroup = groups.find((group) => group.group_id === selectedGroupId);
  const selectedUser = users.find((item) => item.user_id === selectedUserId);

  useEffect(() => {
    directMessagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [directMessages]);

  useEffect(() => {
    groupMessagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [selectedGroupId, groups]);

  const handleDirectKeyDown = (event) => {
    if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      sendDirectMessage();
    }
  };

  const handleGroupKeyDown = (event) => {
    if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      sendGroupMessage();
    }
  };

  const copyGroupId = async () => {
    if (!selectedGroup?.group_id) return;
    try {
      await navigator.clipboard.writeText(selectedGroup.group_id);
      toast.success("Group ID copied");
    } catch {
      try {
        const temp = document.createElement("textarea");
        temp.value = selectedGroup.group_id;
        document.body.appendChild(temp);
        temp.select();
        document.execCommand("copy");
        document.body.removeChild(temp);
        toast.success("Group ID copied");
      } catch {
        toast.info(`Group ID: ${selectedGroup.group_id}`);
      }
    }
  };

  return (
    <section data-testid="messaging-page">
      <h1 className="font-heading text-4xl sm:text-5xl text-[#1e3a8a]" data-testid="messaging-title">
        Messaging & Communication
      </h1>
      <p className="text-base text-slate-600 mt-3 mb-8" data-testid="messaging-description">
        Connect with peers via direct messages, group chats, and admin announcements.
      </p>

      <div className="grid xl:grid-cols-2 gap-6">
        <section className="rounded-2xl border border-slate-200 bg-white p-5" data-testid="direct-messaging-card">
          <h2 className="text-lg font-semibold mb-4" data-testid="direct-messaging-title">Direct Messages</h2>
          <Label htmlFor="direct-user" data-testid="direct-user-select-label">Choose user</Label>
          <select
            id="direct-user"
            className="w-full border border-slate-200 rounded-lg p-2 mt-2"
            value={selectedUserId}
            onChange={(event) => setSelectedUserId(event.target.value)}
            data-testid="direct-user-select"
          >
            {users.map((item) => (
              <option value={item.user_id} key={item.user_id} data-testid={`direct-user-option-${item.user_id}`}>
                {item.name} (@{item.username})
              </option>
            ))}
          </select>

          {selectedUser && (
            <p className="text-xs text-slate-500 mt-2" data-testid="direct-chat-with-label">
              Chatting with: <span className="font-medium">{selectedUser.name}</span>
            </p>
          )}

          <div className="mt-4 rounded-xl border border-slate-200 p-3 h-56 overflow-auto space-y-2" data-testid="direct-messages-list">
            {directMessages.length === 0 ? (
              <p className="text-sm text-slate-500" data-testid="direct-messages-empty">No messages yet.</p>
            ) : (
              directMessages.map((message) => (
                <div key={message.message_id} className={[
                  "rounded-lg p-2 text-sm",
                  message.from_user_id === user?.user_id ? "bg-blue-100 ml-8" : "bg-slate-100 mr-8",
                ].join(" ")} data-testid={`direct-message-${message.message_id}`}>
                  <p className="text-[11px] text-slate-500 mb-1" data-testid={`direct-message-meta-${message.message_id}`}>
                    {message.from_user_id === user?.user_id ? "You" : userMap[message.from_user_id]?.name || "User"} · {new Date(message.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </p>
                  <p data-testid={`direct-message-content-${message.message_id}`}>{message.content}</p>
                </div>
              ))
            )}
            <div ref={directMessagesEndRef} data-testid="direct-messages-end-anchor" />
          </div>

          <div className="mt-4 space-y-2" data-testid="direct-message-input-row">
            <Textarea
              value={directText}
              onChange={(event) => setDirectText(event.target.value)}
              onKeyDown={handleDirectKeyDown}
              placeholder="Type a message... (Enter for next line, Ctrl/Cmd+Enter to send)"
              rows={3}
              data-testid="direct-message-input"
            />
            <Button onClick={sendDirectMessage} data-testid="direct-message-send-button">Send</Button>
            <p className="text-xs text-slate-500" data-testid="direct-message-shortcut-hint">
              Enter = new line · Ctrl/Cmd + Enter = send
            </p>
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-5" data-testid="group-chat-card">
          <h2 className="text-lg font-semibold mb-4" data-testid="group-chat-title">Group Chats</h2>

          <div className="space-y-3 mb-4" data-testid="group-chat-create-form">
            <Input value={groupName} onChange={(event) => setGroupName(event.target.value)} placeholder="Group name" data-testid="group-chat-name-input" />
            <Input value={groupMembers} onChange={(event) => setGroupMembers(event.target.value)} placeholder="Member user IDs (comma separated)" data-testid="group-chat-members-input" />
            <Button variant="outline" onClick={createGroup} data-testid="group-chat-create-button">
              Create Group
            </Button>
          </div>

          <Label htmlFor="group-select" data-testid="group-chat-select-label">Select group</Label>
          <select
            id="group-select"
            className="w-full border border-slate-200 rounded-lg p-2 mt-2"
            value={selectedGroupId}
            onChange={(event) => setSelectedGroupId(event.target.value)}
            data-testid="group-chat-select"
          >
            {groups.map((group) => (
              <option value={group.group_id} key={group.group_id} data-testid={`group-chat-option-${group.group_id}`}>
                {group.name}
              </option>
            ))}
          </select>

          {selectedGroup && (
            <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3" data-testid="group-chat-share-container">
              <p className="text-xs text-slate-600" data-testid="group-chat-group-id-label">Group ID</p>
              <p className="text-xs break-all font-medium" data-testid="group-chat-group-id-value">{selectedGroup.group_id}</p>
              <Button className="mt-2" size="sm" variant="outline" onClick={copyGroupId} data-testid="group-chat-copy-group-id-button">
                Copy Group ID
              </Button>
            </div>
          )}

          <div className="mt-3 flex gap-2" data-testid="group-chat-join-row">
            <Input
              value={joinGroupId}
              onChange={(event) => setJoinGroupId(event.target.value)}
              placeholder="Paste Group ID to join"
              data-testid="group-chat-join-input"
            />
            <Button variant="outline" onClick={joinGroup} data-testid="group-chat-join-button">Join</Button>
          </div>

          <div className="mt-4 rounded-xl border border-slate-200 p-3 h-44 overflow-auto space-y-2" data-testid="group-chat-messages-list">
            {(selectedGroup?.messages || []).length === 0 ? (
              <p className="text-sm text-slate-500" data-testid="group-chat-messages-empty">No messages yet.</p>
            ) : (
              selectedGroup.messages.map((message) => (
                <div key={message.message_id} className="rounded-lg bg-slate-100 p-2 text-sm" data-testid={`group-chat-message-${message.message_id}`}>
                  <p className="text-[11px] text-slate-500 mb-1" data-testid={`group-chat-message-meta-${message.message_id}`}>
                    {message.from_user_id === user?.user_id ? "You" : userMap[message.from_user_id]?.name || "User"} · {new Date(message.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </p>
                  <p data-testid={`group-chat-message-content-${message.message_id}`}>{message.content}</p>
                </div>
              ))
            )}
            <div ref={groupMessagesEndRef} data-testid="group-messages-end-anchor" />
          </div>

          <div className="mt-4 space-y-2" data-testid="group-chat-input-row">
            <Textarea
              value={groupText}
              onChange={(event) => setGroupText(event.target.value)}
              onKeyDown={handleGroupKeyDown}
              placeholder="Type group message... (Enter for next line, Ctrl/Cmd+Enter to send)"
              rows={3}
              data-testid="group-chat-input"
            />
            <Button onClick={sendGroupMessage} data-testid="group-chat-send-button">Send</Button>
            <p className="text-xs text-slate-500" data-testid="group-message-shortcut-hint">
              Enter = new line · Ctrl/Cmd + Enter = send
            </p>
          </div>
        </section>
      </div>

      {hasRole("admin") && (
        <section className="rounded-2xl border border-slate-200 bg-white p-5 mt-6" data-testid="announcement-admin-card">
          <h2 className="text-lg font-semibold mb-4" data-testid="announcement-admin-title">Post Announcement</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="announcement-title" data-testid="announcement-title-label">Title</Label>
              <Input id="announcement-title" value={announcement.title} onChange={(event) => setAnnouncement((prev) => ({ ...prev, title: event.target.value }))} data-testid="announcement-title-input" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="announcement-message" data-testid="announcement-message-label">Message</Label>
              <Textarea id="announcement-message" value={announcement.message} onChange={(event) => setAnnouncement((prev) => ({ ...prev, message: event.target.value }))} data-testid="announcement-message-input" />
            </div>
          </div>
          <Button className="mt-4" onClick={postAnnouncement} data-testid="announcement-submit-button">
            Publish Announcement
          </Button>
        </section>
      )}
    </section>
  );
}
