import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { api, getApiError } from "@/api";
import { toast } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function ResetPasswordPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [newPassword, setNewPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const token = searchParams.get("token") || "";

  const onSubmit = async (event) => {
    event.preventDefault();
    if (!token) {
      toast.error("Reset token missing in URL.");
      return;
    }

    setSubmitting(true);
    try {
      const response = await api.post("/auth/reset-password", {
        token,
        new_password: newPassword,
      });
      toast.success(response.data.message || "Password reset successful");
      navigate("/login");
    } catch (error) {
      toast.error(getApiError(error, "Could not reset password"));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-[#eff6ff] to-[#fdf2f8]" data-testid="reset-password-page">
      <div className="w-full max-w-md rounded-2xl border border-slate-200/80 bg-white p-6 shadow-lg" data-testid="reset-password-card">
        <h1 className="text-2xl font-heading text-[#1e3a8a] mb-2" data-testid="reset-password-title">
          Create a new password
        </h1>
        <p className="text-sm text-slate-600 mb-5" data-testid="reset-password-description">
          Your new password should be at least 8 characters.
        </p>

        <form onSubmit={onSubmit} className="space-y-4" data-testid="reset-password-form">
          <div className="space-y-2">
            <Label htmlFor="new-password" data-testid="reset-password-new-password-label">
              New password
            </Label>
            <Input
              id="new-password"
              type="password"
              data-testid="reset-password-new-password-input"
              value={newPassword}
              onChange={(event) => setNewPassword(event.target.value)}
              required
            />
          </div>

          <Button type="submit" className="w-full" disabled={submitting} data-testid="reset-password-submit-button">
            {submitting ? "Saving..." : "Reset Password"}
          </Button>
        </form>

        <div className="mt-5 text-center" data-testid="reset-password-login-wrapper">
          <Link to="/login" className="text-sm text-slate-600 underline" data-testid="reset-password-login-link">
            Back to login
          </Link>
        </div>
      </div>
    </div>
  );
}
