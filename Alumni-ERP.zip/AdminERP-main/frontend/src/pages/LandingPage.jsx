import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Shield, Users } from "lucide-react";

const heroImage =
  "https://customer-assets.emergentagent.com/job_41ca8096-f5a0-4243-979a-c0c2bb6c1bc3/artifacts/dlao4ph2_image.png";

const featureCards = [
  {
    title: "Profile & Career Tracking",
    text: "Manage student and alumni journeys with internships, jobs, committees, and mentorship signals.",
  },
  {
    title: "Password & Role Control",
    text: "Admin has full control to assign multi-roles, reset passwords, and secure first-login password changes.",
  },
  {
    title: "Charts & Placement Analytics",
    text: "View placement outcomes by course and company with clear bar and pie chart insights.",
  },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#7a0018]" data-testid="landing-page">
      <div className="bg-[#f2c995] text-[#50111e] py-5 px-6 lg:px-14 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm md:text-lg font-medium" data-testid="landing-topline">
          One college. Lifelong community. Real connections.
        </p>
        <Link to="/login" className="underline underline-offset-4 font-semibold" data-testid="landing-admin-login-link">
          Admin Login
        </Link>
      </div>

      <div className="mx-auto max-w-[1400px] px-6 lg:px-14 py-10 lg:py-16">
        <section className="grid lg:grid-cols-2 gap-10 lg:gap-14 items-center" data-testid="landing-hero-section">
          <div>
            <span className="inline-flex items-center rounded-full bg-[#f2c995] text-[#6a1022] px-5 py-2 text-sm tracking-widest mb-6" data-testid="landing-brand-chip">
              ALUMNICONNECT
            </span>
            <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl leading-[1.02] text-white max-w-xl" data-testid="landing-hero-title">
              Your College Story Continues Beyond Graduation.
            </h1>
            <p className="mt-6 text-[#f8d9dd] text-base md:text-lg max-w-xl leading-relaxed" data-testid="landing-hero-description">
              A modern alumni platform where administrators manage profiles, students discover mentors,
              and alumni create meaningful impact through guidance and referrals.
            </p>

            <div className="mt-8 flex flex-wrap gap-4" data-testid="landing-cta-group">
              <Link to="/login" data-testid="landing-enter-admin-link">
                <Button className="rounded-xl bg-[#f2c995] text-[#5a1320] hover:bg-[#f7d7aa] px-7 py-6 text-base" data-testid="landing-enter-admin-button">
                  Enter Admin Panel
                </Button>
              </Link>
              <Link to="/app/directory" data-testid="landing-explore-directory-link">
                <Button variant="outline" className="rounded-xl border-[#f2c995] text-[#fbe9cc] hover:bg-[#8f112c] px-7 py-6 text-base" data-testid="landing-explore-directory-button">
                  Explore Alumni <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>

          <div className="rounded-3xl border border-[#f2c995]/40 bg-[#9f1534] p-4 shadow-2xl" data-testid="landing-hero-image-container">
            <img src={heroImage} alt="AlumniConnect campus" className="w-full rounded-2xl object-cover" data-testid="landing-hero-image" />
          </div>
        </section>

        <section className="mt-14 grid md:grid-cols-3 gap-5" data-testid="landing-features-section">
          {featureCards.map((card) => (
            <article key={card.title} className="rounded-2xl border border-[#f2c995]/35 bg-[#8f112c]/65 p-6 backdrop-blur-md" data-testid={`landing-feature-card-${card.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}>
              <h2 className="text-lg text-[#fcefd6] font-semibold mb-3">{card.title}</h2>
              <p className="text-[#f6ced4] text-sm leading-relaxed">{card.text}</p>
            </article>
          ))}
        </section>

        <section className="mt-12 rounded-2xl border border-[#f2c995]/40 bg-[#f2c995] p-6 flex flex-wrap items-center justify-between gap-4" data-testid="landing-bottom-banner">
          <div>
            <p className="text-[#5b1a28] text-base md:text-lg font-semibold" data-testid="landing-bottom-banner-text">
              Built for placement teams, mentors, student leaders, and alumni communities.
            </p>
          </div>
          <div className="flex gap-3 text-[#5b1a28]" data-testid="landing-bottom-banner-icons">
            <Users className="h-5 w-5" />
            <Shield className="h-5 w-5" />
          </div>
        </section>
      </div>
    </div>
  );
}
