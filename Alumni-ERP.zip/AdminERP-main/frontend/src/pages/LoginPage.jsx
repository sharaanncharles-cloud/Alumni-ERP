import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/context/AuthContext";
import { getApiError } from "@/api";

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ username: "", password: "" });
  const [loading, setLoading] = useState(false);

  const onSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    try {
      const data = await login(form.username, form.password);
      toast.success("Login successful");
      if (data.must_change_password) {
        navigate("/app/change-password");
        return;
      }
      navigate("/app");
    } catch (error) {
      toast.error(getApiError(error, "Login failed"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_#facc15_0%,_#f8fafc_40%,_#fdf2f8_100%)] flex items-center justify-center p-6" data-testid="login-page">
      <Card className="w-full max-w-md rounded-2xl border-slate-200/70 bg-white/90 backdrop-blur-xl" data-testid="login-card">
        <CardHeader>
          <CardTitle className="text-2xl font-heading text-[#1e3a8a]" data-testid="login-title">
            Login to AlumniConnect
          </CardTitle>
          <p className="text-sm text-slate-600" data-testid="login-subtitle">
            Default admin credentials: <strong>admin / butteryellow</strong>
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4" data-testid="login-form">
            <div className="space-y-2">
              <Label htmlFor="username" data-testid="login-username-label">Username</Label>
              <Input
                id="username"
                data-testid="login-username-input"
                value={form.username}
                onChange={(event) => setForm((prev) => ({ ...prev, username: event.target.value }))}
                placeholder="Enter username"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" data-testid="login-password-label">Password</Label>
              <Input
                id="password"
                type="password"
                data-testid="login-password-input"
                value={form.password}
                onChange={(event) => setForm((prev) => ({ ...prev, password: event.target.value }))}
                placeholder="Enter password"
                required
              />
            </div>

            <Button type="submit" className="w-full" disabled={loading} data-testid="login-submit-button">
              {loading ? "Logging in..." : "Login"}
            </Button>

            <div className="text-center" data-testid="login-forgot-wrapper">
              <Link to="/forgot-password" className="text-sm text-[#1e3a8a] underline" data-testid="forgot-password-link">
                Forgot Password?
              </Link>
            </div>

            <div className="text-center" data-testid="login-back-home-wrapper">
              <Link to="/" className="text-sm text-slate-600 underline" data-testid="login-back-home-link">
                Back to Home
              </Link>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
