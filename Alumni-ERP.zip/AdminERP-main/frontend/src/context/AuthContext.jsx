import { createContext, useContext, useEffect, useState } from "react";
import { api } from "@/api";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchMe = async () => {
    const token = localStorage.getItem("alumni_token");
    if (!token) {
      setUser(null);
      setLoading(false);
      return;
    }

    try {
      const response = await api.get("/auth/me");
      setUser(response.data.user);
    } catch {
      localStorage.removeItem("alumni_token");
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMe();
  }, []);

  const login = async (username, password) => {
    const response = await api.post("/auth/login", { username, password });
    localStorage.setItem("alumni_token", response.data.access_token);
    setUser({
      ...response.data.user,
      must_change_password: response.data.must_change_password,
    });
    return response.data;
  };

  const logout = () => {
    localStorage.removeItem("alumni_token");
    setUser(null);
  };

  const refreshProfile = async () => {
    await fetchMe();
  };

  const hasRole = (role) => user?.roles?.includes(role);

  const value = {
    user,
    loading,
    login,
    logout,
    refreshProfile,
    hasRole,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used inside AuthProvider");
  }
  return context;
};
