import "@/App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/sonner";
import { AuthProvider } from "@/context/AuthContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { AppShell } from "@/components/AppShell";
import LandingPage from "@/pages/LandingPage";
import LoginPage from "@/pages/LoginPage";
import ForgotPasswordPage from "@/pages/ForgotPasswordPage";
import ResetPasswordPage from "@/pages/ResetPasswordPage";
import ChangePasswordPage from "@/pages/ChangePasswordPage";
import DashboardHomePage from "@/pages/DashboardHomePage";
import ProfilePage from "@/pages/ProfilePage";
import DirectoryPage from "@/pages/DirectoryPage";
import MessagingPage from "@/pages/MessagingPage";
import GamificationPage from "@/pages/GamificationPage";
import AnalyticsPage from "@/pages/AnalyticsPage";
import AdminUsersPage from "@/pages/AdminUsersPage";

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/reset-password" element={<ResetPasswordPage />} />

            <Route element={<ProtectedRoute />}>
              <Route path="/app" element={<AppShell />}>
                <Route index element={<DashboardHomePage />} />
                <Route path="change-password" element={<ChangePasswordPage />} />
                <Route path="profile" element={<ProfilePage />} />
                <Route path="directory" element={<DirectoryPage />} />
                <Route path="messaging" element={<MessagingPage />} />
                <Route path="gamification" element={<GamificationPage />} />
                <Route
                  path="analytics"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <AnalyticsPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="admin/users"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <AdminUsersPage />
                    </ProtectedRoute>
                  }
                />
              </Route>
            </Route>
          </Routes>
        </BrowserRouter>
        <Toaster position="top-right" richColors />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
